-- ============================================================================
-- STATUS Leasing and Finance - Database Schema
-- PostgreSQL Database Creation Script
-- ============================================================================
-- This script creates all tables, indexes, and constraints for the application
-- Execute this script to set up the complete database schema
-- ============================================================================

-- Drop existing tables if they exist (in reverse dependency order)
-- WARNING: This will delete all data!
DROP TABLE IF EXISTS case_notes CASCADE;
DROP TABLE IF EXISTS case_status_history CASCADE;
DROP TABLE IF EXISTS documents CASCADE;
DROP TABLE IF EXISTS bank_details CASCADE;
DROP TABLE IF EXISTS kyc_documents CASCADE;
DROP TABLE IF EXISTS addresses CASCADE;
DROP TABLE IF EXISTS customers CASCADE;
DROP TABLE IF EXISTS cases CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- ============================================================================
-- 1. USERS TABLE
-- Stores system users who can create cases/forms
-- ============================================================================
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user', -- 'admin', 'user', 'manager', 'president', 'approver'
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for users table
CREATE INDEX idx_users_phone ON users(phone_number);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ============================================================================
-- 2. CASES TABLE
-- Each form submission becomes a case. Links to the user who created it.
-- ============================================================================
CREATE TABLE cases (
    id SERIAL PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL, -- Auto-generated: CASE-YYYYMMDD-XXXX
    created_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    case_type VARCHAR(50) NOT NULL DEFAULT 'customer_registration', -- 'customer_registration', 'loan_application', etc.
    status VARCHAR(50) NOT NULL DEFAULT 'initialized', -- 'initialized', 'manager_approval', 'president_approval', 'final_approval_done', 'rejected', 'cancelled'
    priority VARCHAR(20) DEFAULT 'normal', -- 'low', 'normal', 'high', 'urgent'
    notes TEXT,
    assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL, -- For case assignment
    submitted_at TIMESTAMP,
    closed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for cases table
CREATE INDEX idx_cases_created_by ON cases(created_by);
CREATE INDEX idx_cases_status ON cases(status);
CREATE INDEX idx_cases_case_number ON cases(case_number);
CREATE INDEX idx_cases_assigned_to ON cases(assigned_to);
CREATE INDEX idx_cases_submitted_at ON cases(submitted_at);

-- ============================================================================
-- 3. CUSTOMERS TABLE
-- Stores customer information from the form. Each form submission (case) 
-- contains complete customer details. One case = One customer record (1:1)
-- ============================================================================
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    case_id INTEGER NOT NULL UNIQUE REFERENCES cases(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL DEFAULT 'Individual', -- 'Individual', 'Corporate', etc.
    
    -- Personal Information
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    relation VARCHAR(50), -- 'self', 'father', 'mother', 'spouse', etc.
    relation_first_name VARCHAR(100),
    relation_last_name VARCHAR(100),
    customer_photo_url VARCHAR(500), -- Path to uploaded photo
    
    -- Demographics
    gender VARCHAR(20) NOT NULL,
    date_of_birth DATE NOT NULL,
    age INTEGER,
    marital_status VARCHAR(20) NOT NULL,
    customer_religion VARCHAR(50),
    customer_caste VARCHAR(50),
    
    -- Contact Information (used to identify returning customers)
    primary_contact_no VARCHAR(20) NOT NULL,
    alternate_no VARCHAR(20),
    email VARCHAR(255),
    other_email_id VARCHAR(255),
    whatsapp_no VARCHAR(20),
    
    -- Professional Information
    customer_profile VARCHAR(100), -- 'salaried', 'business', 'professional', etc.
    customer_category VARCHAR(100),
    sub_category VARCHAR(100),
    nature_of_work VARCHAR(100),
    business_type VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for customers table
CREATE INDEX idx_customers_case_id ON customers(case_id);
CREATE INDEX idx_customers_primary_contact ON customers(primary_contact_no);
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_dob ON customers(date_of_birth);

-- ============================================================================
-- 4. ADDRESSES TABLE
-- Stores all addresses (present, permanent, work) for customers. 
-- Normalized design - one address per type per customer.
-- ============================================================================
CREATE TABLE addresses (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    address_type VARCHAR(20) NOT NULL, -- 'present', 'permanent', 'work'
    address_line TEXT NOT NULL,
    landmark VARCHAR(255),
    pincode VARCHAR(10) NOT NULL,
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    tehsil VARCHAR(100) NOT NULL,
    no_of_years VARCHAR(50),
    rent_own VARCHAR(20), -- 'rent', 'own'
    distance_to_branch VARCHAR(50),
    is_communication_address BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(customer_id, address_type) -- One address per type per customer
);

-- Indexes for addresses table
CREATE INDEX idx_addresses_customer_id ON addresses(customer_id);
CREATE INDEX idx_addresses_type ON addresses(address_type);

-- ============================================================================
-- 5. KYC DOCUMENTS TABLE
-- Stores KYC document information. Multiple documents per customer.
-- ============================================================================
CREATE TABLE kyc_documents (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    document_type VARCHAR(100) NOT NULL, -- 'aadhaar', 'pan', 'passport', 'driving_license', 'voter_id', etc.
    document_number VARCHAR(100) NOT NULL,
    document_url VARCHAR(500), -- Path to uploaded document (front)
    document_url_back VARCHAR(500), -- Path to uploaded document (back, if applicable)
    verification_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    verified_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for kyc_documents table
CREATE INDEX idx_kyc_documents_customer_id ON kyc_documents(customer_id);
CREATE INDEX idx_kyc_documents_type ON kyc_documents(document_type);
CREATE INDEX idx_kyc_documents_number ON kyc_documents(document_number);
CREATE INDEX idx_kyc_documents_verification_status ON kyc_documents(verification_status);

-- ============================================================================
-- 6. BANK DETAILS TABLE
-- Stores bank account information. Multiple accounts per customer.
-- ============================================================================
CREATE TABLE bank_details (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    beneficiary VARCHAR(255) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    bank_name VARCHAR(255) NOT NULL,
    bank_branch VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- 'savings', 'current', 'salary', etc.
    ifsc_code VARCHAR(20) NOT NULL,
    micr_code VARCHAR(20),
    is_primary BOOLEAN DEFAULT false, -- Mark primary account
    verification_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for bank_details table
CREATE INDEX idx_bank_details_customer_id ON bank_details(customer_id);
CREATE INDEX idx_bank_details_account_number ON bank_details(account_number);
CREATE INDEX idx_bank_details_ifsc ON bank_details(ifsc_code);
CREATE INDEX idx_bank_details_verification_status ON bank_details(verification_status);

-- ============================================================================
-- 7. DOCUMENTS TABLE
-- Centralized document storage. Stores all uploaded files 
-- (photos, KYC docs, bank statements, etc.).
-- ============================================================================
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    case_id INTEGER REFERENCES cases(id) ON DELETE CASCADE,
    customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
    document_type VARCHAR(100) NOT NULL, -- 'customer_photo', 'kyc_document', 'bank_statement', 'other'
    file_name VARCHAR(255) NOT NULL,
    original_file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL, -- Storage path
    file_size BIGINT NOT NULL, -- Size in bytes
    mime_type VARCHAR(100), -- 'image/jpeg', 'application/pdf', etc.
    upload_type VARCHAR(50), -- 'front', 'back', 'single'
    uploaded_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for documents table
CREATE INDEX idx_documents_case_id ON documents(case_id);
CREATE INDEX idx_documents_customer_id ON documents(customer_id);
CREATE INDEX idx_documents_type ON documents(document_type);
CREATE INDEX idx_documents_uploaded_by ON documents(uploaded_by);

-- ============================================================================
-- 8. CASE STATUS HISTORY TABLE
-- Tracks all status changes and transitions for audit purposes.
-- ============================================================================
CREATE TABLE case_status_history (
    id SERIAL PRIMARY KEY,
    case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    from_status VARCHAR(50), -- Previous status (NULL for initial status)
    to_status VARCHAR(50) NOT NULL, -- New status
    changed_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    comments TEXT, -- Optional comments/reason for status change
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for case_status_history table
CREATE INDEX idx_case_status_history_case_id ON case_status_history(case_id);
CREATE INDEX idx_case_status_history_changed_by ON case_status_history(changed_by);
CREATE INDEX idx_case_status_history_to_status ON case_status_history(to_status);
CREATE INDEX idx_case_status_history_created_at ON case_status_history(created_at);

-- ============================================================================
-- 9. CASE NOTES TABLE
-- For tracking case comments and general notes.
-- ============================================================================
CREATE TABLE case_notes (
    id SERIAL PRIMARY KEY,
    case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    note_type VARCHAR(50) DEFAULT 'comment', -- 'comment', 'assignment', 'system', 'rejection_reason'
    note_text TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT false, -- Internal notes not visible to creator
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for case_notes table
CREATE INDEX idx_case_notes_case_id ON case_notes(case_id);
CREATE INDEX idx_case_notes_user_id ON case_notes(user_id);
CREATE INDEX idx_case_notes_note_type ON case_notes(note_type);

-- ============================================================================
-- FUNCTION: Auto-generate case number
-- Generates case number in format: CASE-YYYYMMDD-XXXX
-- ============================================================================
CREATE OR REPLACE FUNCTION generate_case_number()
RETURNS TRIGGER AS $$
DECLARE
    date_part VARCHAR(8);
    sequence_num INTEGER;
    new_case_number VARCHAR(50);
BEGIN
    -- Get date part (YYYYMMDD)
    date_part := TO_CHAR(CURRENT_DATE, 'YYYYMMDD');
    
    -- Get sequence number for today (count cases created today + 1)
    SELECT COALESCE(MAX(CAST(SUBSTRING(case_number FROM 14) AS INTEGER)), 0) + 1
    INTO sequence_num
    FROM cases
    WHERE case_number LIKE 'CASE-' || date_part || '-%';
    
    -- Format: CASE-YYYYMMDD-XXXX (4 digit sequence)
    new_case_number := 'CASE-' || date_part || '-' || LPAD(sequence_num::TEXT, 4, '0');
    
    NEW.case_number := new_case_number;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-generate case number before insert
CREATE TRIGGER trigger_generate_case_number
    BEFORE INSERT ON cases
    FOR EACH ROW
    WHEN (NEW.case_number IS NULL OR NEW.case_number = '')
    EXECUTE FUNCTION generate_case_number();

-- ============================================================================
-- FUNCTION: Auto-create status history entry
-- Automatically creates a status history entry when case status changes
-- ============================================================================
CREATE OR REPLACE FUNCTION create_status_history()
RETURNS TRIGGER AS $$
BEGIN
    -- Only create history if status actually changed
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        INSERT INTO case_status_history (
            case_id,
            from_status,
            to_status,
            changed_by,
            comments
        ) VALUES (
            NEW.id,
            OLD.status,
            NEW.status,
            NEW.created_by, -- Default to case creator, can be overridden in application
            NULL
        );
        
        -- Update submitted_at when moving from initialized to manager_approval
        IF OLD.status = 'initialized' AND NEW.status = 'manager_approval' THEN
            NEW.submitted_at := CURRENT_TIMESTAMP;
        END IF;
        
        -- Update closed_at when reaching final_approval_done
        IF NEW.status = 'final_approval_done' THEN
            NEW.closed_at := CURRENT_TIMESTAMP;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to auto-create status history
CREATE TRIGGER trigger_create_status_history
    AFTER UPDATE OF status ON cases
    FOR EACH ROW
    EXECUTE FUNCTION create_status_history();

-- ============================================================================
-- FUNCTION: Auto-create initial status history
-- Creates initial status history entry when case is first created
-- ============================================================================
CREATE OR REPLACE FUNCTION create_initial_status_history()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO case_status_history (
        case_id,
        from_status,
        to_status,
        changed_by,
        comments
    ) VALUES (
        NEW.id,
        NULL, -- No previous status for initial creation
        NEW.status,
        NEW.created_by,
        'Case created'
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to create initial status history
CREATE TRIGGER trigger_create_initial_status_history
    AFTER INSERT ON cases
    FOR EACH ROW
    EXECUTE FUNCTION create_initial_status_history();

-- ============================================================================
-- FUNCTION: Update updated_at timestamp
-- Automatically updates the updated_at column when a row is modified
-- ============================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at := CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at trigger to relevant tables
CREATE TRIGGER trigger_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_cases_updated_at
    BEFORE UPDATE ON cases
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_customers_updated_at
    BEFORE UPDATE ON customers
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_addresses_updated_at
    BEFORE UPDATE ON addresses
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_kyc_documents_updated_at
    BEFORE UPDATE ON kyc_documents
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trigger_bank_details_updated_at
    BEFORE UPDATE ON bank_details
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- COMMENTS ON TABLES (Documentation)
-- ============================================================================
COMMENT ON TABLE users IS 'Stores system users who can create cases/forms';
COMMENT ON TABLE cases IS 'Each form submission becomes a case. Links to the user who created it.';
COMMENT ON TABLE customers IS 'Stores customer information from the form. One case = One customer record (1:1 relationship)';
COMMENT ON TABLE addresses IS 'Stores all addresses (present, permanent, work) for customers. Normalized design.';
COMMENT ON TABLE kyc_documents IS 'Stores KYC document information. Multiple documents per customer.';
COMMENT ON TABLE bank_details IS 'Stores bank account information. Multiple accounts per customer.';
COMMENT ON TABLE documents IS 'Centralized document storage. Stores all uploaded files.';
COMMENT ON TABLE case_status_history IS 'Tracks all status changes and transitions for audit purposes.';
COMMENT ON TABLE case_notes IS 'For tracking case comments and general notes.';

-- ============================================================================
-- END OF SCHEMA CREATION
-- ============================================================================

-- Verify tables were created
SELECT 
    table_name,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name) as column_count
FROM information_schema.tables t
WHERE table_schema = 'public' 
    AND table_type = 'BASE TABLE'
    AND table_name IN ('users', 'cases', 'customers', 'addresses', 'kyc_documents', 'bank_details', 'documents', 'case_status_history', 'case_notes')
ORDER BY table_name;
