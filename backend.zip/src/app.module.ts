import { Module } from '@nestjs/common'
import { ConfigModule, ConfigService } from '@nestjs/config'
import { TypeOrmModule } from '@nestjs/typeorm'
import { AuthModule } from './auth/auth.module'
import { CustomerModule } from './customer/customer.module'
import { CaseModule } from './case/case.module'
import {
  User,
  Case,
  Customer,
  Address,
  KycDocument,
  BankDetail,
  Document,
  CaseStatusHistory,
  CaseNote,
} from './entities'

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    TypeOrmModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => ({
        type: 'postgres',
        host: configService.get<string>('DB_HOST', 'localhost'),
        port: configService.get<number>('DB_PORT', 5432),
        username: configService.get<string>('DB_USERNAME', 'postgres'),
        password: configService.get<string>('DB_PASSWORD'),
        database: configService.get<string>('DB_NAME', 'auth_database'),
        entities: [
          User,
          Case,
          Customer,
          Address,
          KycDocument,
          BankDetail,
          Document,
          CaseStatusHistory,
          CaseNote,
        ],
        synchronize: configService.get<string>('NODE_ENV') === 'development',
        logging: configService.get<string>('NODE_ENV') === 'development',
      }),
    }),
    AuthModule,
    CustomerModule,
    CaseModule,
  ],
})
export class AppModule {}
