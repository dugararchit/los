import { Injectable, BadRequestException } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository, DataSource } from 'typeorm'
import { CreateCustomerDto } from './dto/create-customer.dto'
import { Case, CaseStatus, CaseType } from '../entities/case.entity'
import { Customer } from '../entities/customer.entity'
import { Address, AddressType } from '../entities/address.entity'
import { KycDocument } from '../entities/kyc-document.entity'
import { BankDetail } from '../entities/bank-detail.entity'

@Injectable()
export class CustomerService {
  constructor(
    @InjectRepository(Case)
    private caseRepository: Repository<Case>,
    @InjectRepository(Customer)
    private customerRepository: Repository<Customer>,
    @InjectRepository(Address)
    private addressRepository: Repository<Address>,
    @InjectRepository(KycDocument)
    private kycDocumentRepository: Repository<KycDocument>,
    @InjectRepository(BankDetail)
    private bankDetailRepository: Repository<BankDetail>,
    private dataSource: DataSource,
  ) {}

  async create(createCustomerDto: CreateCustomerDto, userId: number) {
    const queryRunner = this.dataSource.createQueryRunner()
    await queryRunner.connect()
    await queryRunner.startTransaction()

    try {
      // Create case
      const caseEntity = queryRunner.manager.create(Case, {
        created_by: userId,
        case_type: CaseType.CUSTOMER_REGISTRATION,
        status: CaseStatus.INITIALIZED,
      })
      const savedCase = await queryRunner.manager.save(Case, caseEntity)

      // Calculate age from DOB
      const dob = new Date(createCustomerDto.dob)
      const age = Math.floor(
        (Date.now() - dob.getTime()) / (1000 * 60 * 60 * 24 * 365.25),
      )

      // Create customer
      const customer = queryRunner.manager.create(Customer, {
        case_id: savedCase.id,
        type: createCustomerDto.type,
        first_name: createCustomerDto.firstName,
        last_name: createCustomerDto.lastName,
        relation: createCustomerDto.relation,
        relation_first_name: createCustomerDto.relationFirstName,
        relation_last_name: createCustomerDto.relationLastName,
        gender: createCustomerDto.gender,
        date_of_birth: dob,
        age,
        marital_status: createCustomerDto.maritalStatus,
        customer_religion: createCustomerDto.customerReligion,
        customer_caste: createCustomerDto.customerCaste,
        primary_contact_no: createCustomerDto.primaryContactNo,
        alternate_no: createCustomerDto.alternateNo,
        email: createCustomerDto.email,
        other_email_id: createCustomerDto.otherEmailId,
        whatsapp_no: createCustomerDto.whatsAppNo,
        customer_profile: createCustomerDto.customerProfile,
        customer_category: createCustomerDto.customerCategory,
        sub_category: createCustomerDto.subCategory,
        nature_of_work: createCustomerDto.natureOfWork,
        business_type: createCustomerDto.businessType,
      })
      const savedCustomer = await queryRunner.manager.save(Customer, customer)

      // Create addresses
      const addresses: Address[] = []

      // Present address
      addresses.push(
        queryRunner.manager.create(Address, {
          customer_id: savedCustomer.id,
          address_type: AddressType.PRESENT,
          address_line: createCustomerDto.presentAddress,
          landmark: createCustomerDto.presentLandmark,
          pincode: createCustomerDto.presentPinCode,
          state: createCustomerDto.presentState,
          district: createCustomerDto.presentDistrict,
          tehsil: createCustomerDto.presentTehsil,
          no_of_years: createCustomerDto.presentNoOfYears,
          rent_own: createCustomerDto.presentRentOwn,
          distance_to_branch: createCustomerDto.presentDistance,
          is_communication_address: createCustomerDto.presentIsCommunication || false,
        }),
      )

      // Permanent address
      if (createCustomerDto.permanentSameAsPresent) {
        addresses.push(
          queryRunner.manager.create(Address, {
            customer_id: savedCustomer.id,
            address_type: AddressType.PERMANENT,
            address_line: createCustomerDto.presentAddress,
            landmark: createCustomerDto.presentLandmark,
            pincode: createCustomerDto.presentPinCode,
            state: createCustomerDto.presentState,
            district: createCustomerDto.presentDistrict,
            tehsil: createCustomerDto.presentTehsil,
            no_of_years: createCustomerDto.permanentNoOfYears,
            rent_own: createCustomerDto.permanentRentOwn,
            distance_to_branch: createCustomerDto.permanentDistance,
            is_communication_address: createCustomerDto.permanentIsCommunication || false,
          }),
        )
      } else {
        addresses.push(
          queryRunner.manager.create(Address, {
            customer_id: savedCustomer.id,
            address_type: AddressType.PERMANENT,
            address_line: createCustomerDto.permanentAddress,
            landmark: createCustomerDto.permanentLandmark,
            pincode: createCustomerDto.permanentPinCode,
            state: createCustomerDto.permanentState,
            district: createCustomerDto.permanentDistrict,
            tehsil: createCustomerDto.permanentTehsil,
            no_of_years: createCustomerDto.permanentNoOfYears,
            rent_own: createCustomerDto.permanentRentOwn,
            distance_to_branch: createCustomerDto.permanentDistance,
            is_communication_address: createCustomerDto.permanentIsCommunication || false,
          }),
        )
      }

      // Work address (optional)
      if (createCustomerDto.workAddress) {
        addresses.push(
          queryRunner.manager.create(Address, {
            customer_id: savedCustomer.id,
            address_type: AddressType.WORK,
            address_line: createCustomerDto.workAddress,
            landmark: createCustomerDto.workLandmark,
            pincode: createCustomerDto.workPinCode,
            state: createCustomerDto.workState,
            district: createCustomerDto.workDistrict,
            tehsil: createCustomerDto.workTehsil,
            no_of_years: createCustomerDto.workNoOfYears,
            rent_own: createCustomerDto.workRentOwn,
            distance_to_branch: createCustomerDto.workDistance,
            is_communication_address: createCustomerDto.workIsCommunication || false,
          }),
        )
      }

      await queryRunner.manager.save(Address, addresses)

      // Create KYC documents
      if (createCustomerDto.kycDocuments && createCustomerDto.kycDocuments.length > 0) {
        const kycDocuments = createCustomerDto.kycDocuments.map((kyc) =>
          queryRunner.manager.create(KycDocument, {
            customer_id: savedCustomer.id,
            document_type: kyc.documentType,
            document_number: kyc.documentNumber,
            // TODO: Handle file uploads for document_url and document_url_back
          }),
        )
        await queryRunner.manager.save(KycDocument, kycDocuments)
      }

      // Create bank details
      if (createCustomerDto.bankDetails && createCustomerDto.bankDetails.length > 0) {
        const bankDetails = createCustomerDto.bankDetails.map((bank, index) =>
          queryRunner.manager.create(BankDetail, {
            customer_id: savedCustomer.id,
            beneficiary: bank.beneficiary,
            account_number: bank.accountNo,
            bank_name: bank.bankName,
            bank_branch: bank.bankBranch,
            account_type: bank.accountType,
            ifsc_code: bank.ifscCode,
            micr_code: bank.micrCode,
            is_primary: index === 0, // First bank account is primary
          }),
        )
        await queryRunner.manager.save(BankDetail, bankDetails)
      }

      await queryRunner.commitTransaction()

      // Return complete case with customer
      return this.caseRepository.findOne({
        where: { id: savedCase.id },
        relations: ['customer', 'customer.addresses', 'customer.kyc_documents', 'customer.bank_details'],
      })
    } catch (error) {
      await queryRunner.rollbackTransaction()
      throw new BadRequestException(`Failed to create customer: ${error.message}`)
    } finally {
      await queryRunner.release()
    }
  }

  async findAll(): Promise<Customer[]> {
    return this.customerRepository.find({
      relations: [
        'case',
        'case.created_by_user',
        'addresses',
        'kyc_documents',
        'bank_details',
      ],
      order: { created_at: 'DESC' },
    })
  }

  async findOne(id: number): Promise<Customer> {
    const customer = await this.customerRepository.findOne({
      where: { id },
      relations: [
        'case',
        'case.created_by_user',
        'case.assigned_to_user',
        'addresses',
        'kyc_documents',
        'kyc_documents.verified_by_user',
        'bank_details',
        'bank_details.verified_by_user',
      ],
    })

    if (!customer) {
      throw new BadRequestException(`Customer with ID ${id} not found`)
    }

    return customer
  }

  async search(searchBy: string, value: string) {
    const queryBuilder = this.customerRepository
      .createQueryBuilder('customer')
      .leftJoinAndSelect('customer.case', 'case')
      .leftJoinAndSelect('case.created_by_user', 'created_by_user')
      .leftJoinAndSelect('customer.addresses', 'addresses')

    // Map frontend field names to database column names
    switch (searchBy) {
      case 'primaryContactNo':
      case 'primary_contact_no':
        queryBuilder.where('customer.primary_contact_no LIKE :value', {
          value: `%${value}%`,
        })
        break
      case 'email':
        queryBuilder.where(
          '(customer.email LIKE :value OR customer.other_email_id LIKE :value)',
          { value: `%${value}%` },
        )
        break
      case 'firstName':
      case 'first_name':
        queryBuilder.where('customer.first_name LIKE :value', {
          value: `%${value}%`,
        })
        break
      case 'caseNumber':
      case 'case_number':
        queryBuilder.where('case.case_number LIKE :value', {
          value: `%${value}%`,
        })
        break
      default:
        throw new BadRequestException(`Invalid search field: ${searchBy}`)
    }

    return queryBuilder.getMany()
  }
}
