import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { CustomerController } from './customer.controller'
import { CustomerService } from './customer.service'
import { Case } from '../entities/case.entity'
import { Customer } from '../entities/customer.entity'
import { Address } from '../entities/address.entity'
import { KycDocument } from '../entities/kyc-document.entity'
import { BankDetail } from '../entities/bank-detail.entity'

@Module({
  imports: [
    TypeOrmModule.forFeature([Case, Customer, Address, KycDocument, BankDetail]),
  ],
  controllers: [CustomerController],
  providers: [CustomerService],
  exports: [CustomerService],
})
export class CustomerModule {}
