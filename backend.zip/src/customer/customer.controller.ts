import {
  Controller,
  Get,
  Post,
  Body,
  Query,
  Param,
  UseGuards,
  Request,
  BadRequestException,
} from '@nestjs/common'
import { CustomerService } from './customer.service'
import { CreateCustomerDto } from './dto/create-customer.dto'
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard'
import { RolesGuard } from '../auth/guards/roles.guard'
import { Roles } from '../auth/decorators/roles.decorator'
import { UserRole } from '../entities/user.entity'

@Controller('customers')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CustomerController {
  constructor(private readonly customerService: CustomerService) {}

  @Get()
  @Roles(UserRole.ADMIN, UserRole.USER, UserRole.MANAGER, UserRole.PRESIDENT)
  findAll() {
    return this.customerService.findAll()
  }

  @Get('search')
  @Roles(UserRole.ADMIN, UserRole.USER, UserRole.MANAGER, UserRole.PRESIDENT)
  search(@Query('searchBy') searchBy: string, @Query('value') value: string) {
    if (!searchBy || !value) {
      throw new BadRequestException('searchBy and value are required')
    }
    return this.customerService.search(searchBy, value)
  }

  @Get(':id')
  @Roles(UserRole.ADMIN, UserRole.USER, UserRole.MANAGER, UserRole.PRESIDENT)
  findOne(@Param('id') id: string) {
    return this.customerService.findOne(+id)
  }

  @Post()
  @Roles(UserRole.ADMIN, UserRole.USER)
  create(@Body() createCustomerDto: CreateCustomerDto, @Request() req) {
    return this.customerService.create(createCustomerDto, req.user.user.id)
  }
}
