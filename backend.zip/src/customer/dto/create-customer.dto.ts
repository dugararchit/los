import { IsString, IsOptional, IsEmail, IsBoolean, IsArray } from 'class-validator'

export class KycDocumentDto {
  @IsString()
  documentType: string

  @IsString()
  documentNumber: string

  @IsOptional()
  documentImage?: any

  @IsOptional()
  documentImage1?: any
}

export class BankDetailDto {
  @IsString()
  beneficiary: string

  @IsString()
  accountNo: string

  @IsString()
  bankName: string

  @IsString()
  bankBranch: string

  @IsString()
  accountType: string

  @IsString()
  ifscCode: string

  @IsString()
  micrCode: string
}

export class CreateCustomerDto {
  @IsString()
  type: string

  @IsArray()
  kycDocuments: KycDocumentDto[]

  @IsString()
  firstName: string

  @IsOptional()
  @IsString()
  lastName?: string

  @IsString()
  relation: string

  @IsOptional()
  @IsString()
  relationFirstName?: string

  @IsOptional()
  @IsString()
  relationLastName?: string

  @IsOptional()
  customerPhoto?: any

  @IsString()
  gender: string

  @IsString()
  dob: string

  @IsOptional()
  @IsString()
  age?: string

  @IsString()
  primaryContactNo: string

  @IsOptional()
  @IsEmail()
  email?: string

  @IsOptional()
  @IsEmail()
  otherEmailId?: string

  @IsOptional()
  @IsString()
  whatsAppNo?: string

  @IsString()
  maritalStatus: string

  @IsString()
  customerReligion: string

  @IsOptional()
  @IsString()
  alternateNo?: string

  @IsString()
  customerProfile: string

  @IsString()
  customerCategory: string

  @IsString()
  subCategory: string

  @IsString()
  natureOfWork: string

  @IsString()
  customerCaste: string

  @IsString()
  businessType: string

  // Present Address
  @IsString()
  presentAddress: string

  @IsString()
  presentLandmark: string

  @IsString()
  presentPinCode: string

  @IsString()
  presentState: string

  @IsString()
  presentDistrict: string

  @IsString()
  presentTehsil: string

  @IsString()
  presentNoOfYears: string

  @IsString()
  presentRentOwn: string

  @IsString()
  presentDistance: string

  @IsOptional()
  @IsBoolean()
  presentIsCommunication?: boolean

  // Permanent Address
  @IsOptional()
  @IsBoolean()
  permanentSameAsPresent?: boolean

  @IsString()
  permanentAddress: string

  @IsString()
  permanentLandmark: string

  @IsString()
  permanentPinCode: string

  @IsString()
  permanentState: string

  @IsString()
  permanentDistrict: string

  @IsString()
  permanentTehsil: string

  @IsString()
  permanentNoOfYears: string

  @IsString()
  permanentRentOwn: string

  @IsString()
  permanentDistance: string

  @IsOptional()
  @IsBoolean()
  permanentIsCommunication?: boolean

  // Work Address
  @IsOptional()
  @IsString()
  workAddress?: string

  @IsOptional()
  @IsString()
  workLandmark?: string

  @IsOptional()
  @IsString()
  workPinCode?: string

  @IsOptional()
  @IsString()
  workState?: string

  @IsOptional()
  @IsString()
  workDistrict?: string

  @IsOptional()
  @IsString()
  workTehsil?: string

  @IsOptional()
  @IsString()
  workNoOfYears?: string

  @IsOptional()
  @IsString()
  workRentOwn?: string

  @IsOptional()
  @IsString()
  workDistance?: string

  @IsOptional()
  @IsBoolean()
  workIsCommunication?: boolean

  @IsArray()
  bankDetails: BankDetailDto[]
}
