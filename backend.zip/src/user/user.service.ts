import { Injectable } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository } from 'typeorm'
import { User } from '../entities/user.entity'
import * as bcrypt from 'bcrypt'

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  async findByUsernameOrPhone(identifier: string): Promise<User | null> {
    return this.userRepository.findOne({
      where: [
        { username: identifier },
        { phone_number: identifier },
      ],
    })
  }

  async findById(id: number): Promise<User | null> {
    return this.userRepository.findOne({ where: { id } })
  }

  async validatePassword(
    plainPassword: string,
    hashedPassword: string,
  ): Promise<boolean> {
    return bcrypt.compare(plainPassword, hashedPassword)
  }

  async updateLastLogin(userId: number): Promise<void> {
    await this.userRepository.update(userId, {
      last_login: new Date(),
    })
  }
}
