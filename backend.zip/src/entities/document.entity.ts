import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm'
import { Case } from './case.entity'
import { Customer } from './customer.entity'
import { User } from './user.entity'

@Entity('documents')
export class Document {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int', nullable: true })
  @Index()
  case_id: number

  @ManyToOne(() => Case, (caseEntity) => caseEntity.documents, {
    nullable: true,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'case_id' })
  case: Case

  @Column({ type: 'int', nullable: true })
  @Index()
  customer_id: number

  @ManyToOne(() => Customer, (customer) => customer.documents, {
    nullable: true,
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'customer_id' })
  customer: Customer

  @Column({ type: 'varchar', length: 100 })
  @Index()
  document_type: string

  @Column({ type: 'varchar', length: 255 })
  file_name: string

  @Column({ type: 'varchar', length: 255 })
  original_file_name: string

  @Column({ type: 'varchar', length: 500 })
  file_path: string

  @Column({ type: 'bigint' })
  file_size: number

  @Column({ type: 'varchar', length: 100, nullable: true })
  mime_type: string

  @Column({ type: 'varchar', length: 50, nullable: true })
  upload_type: string

  @Column({ type: 'int' })
  @Index()
  uploaded_by: number

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'uploaded_by' })
  uploaded_by_user: User

  @Column({ type: 'text', nullable: true })
  description: string

  @CreateDateColumn()
  created_at: Date
}
