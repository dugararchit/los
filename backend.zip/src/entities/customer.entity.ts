import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToOne,
  ManyToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm'
import { Case } from './case.entity'
import { Address } from './address.entity'
import { KycDocument } from './kyc-document.entity'
import { BankDetail } from './bank-detail.entity'
import { Document } from './document.entity'

@Entity('customers')
export class Customer {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int', unique: true })
  @Index()
  case_id: number

  @OneToOne(() => Case, (caseEntity) => caseEntity.customer, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'case_id' })
  case: Case

  @Column({ type: 'varchar', length: 50, default: 'Individual' })
  type: string

  // Personal Information
  @Column({ type: 'varchar', length: 100 })
  first_name: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  last_name: string

  @Column({ type: 'varchar', length: 50, nullable: true })
  relation: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  relation_first_name: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  relation_last_name: string

  @Column({ type: 'varchar', length: 500, nullable: true })
  customer_photo_url: string

  // Demographics
  @Column({ type: 'varchar', length: 20 })
  gender: string

  @Column({ type: 'date' })
  @Index()
  date_of_birth: Date

  @Column({ type: 'int', nullable: true })
  age: number

  @Column({ type: 'varchar', length: 20 })
  marital_status: string

  @Column({ type: 'varchar', length: 50, nullable: true })
  customer_religion: string

  @Column({ type: 'varchar', length: 50, nullable: true })
  customer_caste: string

  // Contact Information
  @Column({ type: 'varchar', length: 20 })
  @Index()
  primary_contact_no: string

  @Column({ type: 'varchar', length: 20, nullable: true })
  alternate_no: string

  @Column({ type: 'varchar', length: 255, nullable: true })
  @Index()
  email: string

  @Column({ type: 'varchar', length: 255, nullable: true })
  other_email_id: string

  @Column({ type: 'varchar', length: 20, nullable: true })
  whatsapp_no: string

  // Professional Information
  @Column({ type: 'varchar', length: 100, nullable: true })
  customer_profile: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  customer_category: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  sub_category: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  nature_of_work: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  business_type: string

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date

  @OneToMany(() => Address, (address) => address.customer)
  addresses: Address[]

  @OneToMany(() => KycDocument, (kyc) => kyc.customer)
  kyc_documents: KycDocument[]

  @OneToMany(() => BankDetail, (bank) => bank.customer)
  bank_details: BankDetail[]

  @OneToMany(() => Document, (document) => document.customer)
  documents: Document[]
}
