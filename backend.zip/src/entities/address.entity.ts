import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
  Unique,
} from 'typeorm'
import { Customer } from './customer.entity'

export enum AddressType {
  PRESENT = 'present',
  PERMANENT = 'permanent',
  WORK = 'work',
}

@Entity('addresses')
@Unique(['customer_id', 'address_type'])
export class Address {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int' })
  @Index()
  customer_id: number

  @ManyToOne(() => Customer, (customer) => customer.addresses, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'customer_id' })
  customer: Customer

  @Column({ type: 'varchar', length: 20 })
  @Index()
  address_type: AddressType

  @Column({ type: 'text' })
  address_line: string

  @Column({ type: 'varchar', length: 255, nullable: true })
  landmark: string

  @Column({ type: 'varchar', length: 10 })
  pincode: string

  @Column({ type: 'varchar', length: 100 })
  state: string

  @Column({ type: 'varchar', length: 100 })
  district: string

  @Column({ type: 'varchar', length: 100 })
  tehsil: string

  @Column({ type: 'varchar', length: 50, nullable: true })
  no_of_years: string

  @Column({ type: 'varchar', length: 20, nullable: true })
  rent_own: string

  @Column({ type: 'varchar', length: 50, nullable: true })
  distance_to_branch: string

  @Column({ type: 'boolean', default: false })
  is_communication_address: boolean

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
