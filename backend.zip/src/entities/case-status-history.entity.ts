import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm'
import { Case } from './case.entity'
import { User } from './user.entity'

@Entity('case_status_history')
export class CaseStatusHistory {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int' })
  @Index()
  case_id: number

  @ManyToOne(() => Case, (caseEntity) => caseEntity.status_history, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'case_id' })
  case: Case

  @Column({ type: 'varchar', length: 50, nullable: true })
  from_status: string

  @Column({ type: 'varchar', length: 50 })
  @Index()
  to_status: string

  @Column({ type: 'int' })
  @Index()
  changed_by: number

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'changed_by' })
  changed_by_user: User

  @Column({ type: 'text', nullable: true })
  comments: string

  @CreateDateColumn()
  @Index()
  created_at: Date
}
