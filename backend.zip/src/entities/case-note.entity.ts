import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm'
import { Case } from './case.entity'
import { User } from './user.entity'

export enum NoteType {
  COMMENT = 'comment',
  ASSIGNMENT = 'assignment',
  SYSTEM = 'system',
  REJECTION_REASON = 'rejection_reason',
}

@Entity('case_notes')
export class CaseNote {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int' })
  @Index()
  case_id: number

  @ManyToOne(() => Case, (caseEntity) => caseEntity.notes_history, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'case_id' })
  case: Case

  @Column({ type: 'int' })
  @Index()
  user_id: number

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'user_id' })
  user: User

  @Column({
    type: 'varchar',
    length: 50,
    default: NoteType.COMMENT,
  })
  @Index()
  note_type: NoteType

  @Column({ type: 'text' })
  note_text: string

  @Column({ type: 'boolean', default: false })
  is_internal: boolean

  @CreateDateColumn()
  created_at: Date
}
