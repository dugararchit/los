import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
  Index,
} from 'typeorm'
import { Case } from './case.entity'

export enum UserRole {
  ADMIN = 'admin',
  USER = 'user',
  MANAGER = 'manager',
  PRESIDENT = 'president',
  APPROVER = 'approver',
}

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'varchar', length: 100, unique: true })
  @Index()
  username: string

  @Column({ type: 'varchar', length: 255, unique: true, nullable: true })
  @Index()
  email: string

  @Column({ type: 'varchar', length: 20, unique: true })
  @Index()
  phone_number: string

  @Column({ type: 'varchar', length: 255 })
  password_hash: string

  @Column({
    type: 'varchar',
    length: 50,
    default: UserRole.USER,
  })
  @Index()
  role: UserRole

  @Column({ type: 'varchar', length: 100, nullable: true })
  first_name: string

  @Column({ type: 'varchar', length: 100, nullable: true })
  last_name: string

  @Column({ type: 'boolean', default: true })
  is_active: boolean

  @Column({ type: 'timestamp', nullable: true })
  last_login: Date

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date

  @OneToMany(() => Case, (caseEntity) => caseEntity.created_by_user)
  created_cases: Case[]

  @OneToMany(() => Case, (caseEntity) => caseEntity.assigned_to_user)
  assigned_cases: Case[]
}
