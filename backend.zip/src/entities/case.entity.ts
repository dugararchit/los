import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToOne,
  OneToMany,
  JoinColumn,
  Index,
} from 'typeorm'
import { User } from './user.entity'
import { Customer } from './customer.entity'
import { CaseStatusHistory } from './case-status-history.entity'
import { CaseNote } from './case-note.entity'
import { Document } from './document.entity'

export enum CaseStatus {
  INITIALIZED = 'initialized',
  MANAGER_APPROVAL = 'manager_approval',
  PRESIDENT_APPROVAL = 'president_approval',
  FINAL_APPROVAL_DONE = 'final_approval_done',
  REJECTED = 'rejected',
  CANCELLED = 'cancelled',
}

export enum CaseType {
  CUSTOMER_REGISTRATION = 'customer_registration',
  LOAN_APPLICATION = 'loan_application',
}

export enum Priority {
  LOW = 'low',
  NORMAL = 'normal',
  HIGH = 'high',
  URGENT = 'urgent',
}

@Entity('cases')
export class Case {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'varchar', length: 50, unique: true })
  @Index()
  case_number: string

  @Column({ type: 'int' })
  @Index()
  created_by: number

  @ManyToOne(() => User, { onDelete: 'RESTRICT' })
  @JoinColumn({ name: 'created_by' })
  created_by_user: User

  @Column({
    type: 'varchar',
    length: 50,
    default: CaseType.CUSTOMER_REGISTRATION,
  })
  case_type: CaseType

  @Column({
    type: 'varchar',
    length: 50,
    default: CaseStatus.INITIALIZED,
  })
  @Index()
  status: CaseStatus

  @Column({ type: 'varchar', length: 20, default: Priority.NORMAL, nullable: true })
  priority: Priority

  @Column({ type: 'text', nullable: true })
  notes: string

  @Column({ type: 'int', nullable: true })
  @Index()
  assigned_to: number

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'assigned_to' })
  assigned_to_user: User

  @Column({ type: 'timestamp', nullable: true })
  @Index()
  submitted_at: Date

  @Column({ type: 'timestamp', nullable: true })
  closed_at: Date

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date

  @OneToOne(() => Customer, (customer) => customer.case)
  customer: Customer

  @OneToMany(() => CaseStatusHistory, (history) => history.case)
  status_history: CaseStatusHistory[]

  @OneToMany(() => CaseNote, (note) => note.case)
  notes_history: CaseNote[]

  @OneToMany(() => Document, (document) => document.case)
  documents: Document[]
}
