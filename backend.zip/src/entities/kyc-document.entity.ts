import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm'
import { Customer } from './customer.entity'
import { User } from './user.entity'

export enum VerificationStatus {
  PENDING = 'pending',
  VERIFIED = 'verified',
  REJECTED = 'rejected',
}

@Entity('kyc_documents')
export class KycDocument {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int' })
  @Index()
  customer_id: number

  @ManyToOne(() => Customer, (customer) => customer.kyc_documents, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'customer_id' })
  customer: Customer

  @Column({ type: 'varchar', length: 100 })
  @Index()
  document_type: string

  @Column({ type: 'varchar', length: 100 })
  @Index()
  document_number: string

  @Column({ type: 'varchar', length: 500, nullable: true })
  document_url: string

  @Column({ type: 'varchar', length: 500, nullable: true })
  document_url_back: string

  @Column({
    type: 'varchar',
    length: 50,
    default: VerificationStatus.PENDING,
  })
  @Index()
  verification_status: VerificationStatus

  @Column({ type: 'int', nullable: true })
  verified_by: number

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'verified_by' })
  verified_by_user: User

  @Column({ type: 'timestamp', nullable: true })
  verified_at: Date

  @Column({ type: 'text', nullable: true })
  notes: string

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
