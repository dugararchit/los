import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  Index,
} from 'typeorm'
import { Customer } from './customer.entity'
import { User } from './user.entity'
import { VerificationStatus } from './kyc-document.entity'

@Entity('bank_details')
export class BankDetail {
  @PrimaryGeneratedColumn()
  id: number

  @Column({ type: 'int' })
  @Index()
  customer_id: number

  @ManyToOne(() => Customer, (customer) => customer.bank_details, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'customer_id' })
  customer: Customer

  @Column({ type: 'varchar', length: 255 })
  beneficiary: string

  @Column({ type: 'varchar', length: 50 })
  @Index()
  account_number: string

  @Column({ type: 'varchar', length: 255 })
  bank_name: string

  @Column({ type: 'varchar', length: 255 })
  bank_branch: string

  @Column({ type: 'varchar', length: 50 })
  account_type: string

  @Column({ type: 'varchar', length: 20 })
  @Index()
  ifsc_code: string

  @Column({ type: 'varchar', length: 20, nullable: true })
  micr_code: string

  @Column({ type: 'boolean', default: false })
  is_primary: boolean

  @Column({
    type: 'varchar',
    length: 50,
    default: VerificationStatus.PENDING,
  })
  @Index()
  verification_status: VerificationStatus

  @Column({ type: 'int', nullable: true })
  verified_by: number

  @ManyToOne(() => User, { nullable: true, onDelete: 'SET NULL' })
  @JoinColumn({ name: 'verified_by' })
  verified_by_user: User

  @Column({ type: 'timestamp', nullable: true })
  verified_at: Date

  @CreateDateColumn()
  created_at: Date

  @UpdateDateColumn()
  updated_at: Date
}
