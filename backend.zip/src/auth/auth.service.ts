import { Injectable, UnauthorizedException } from '@nestjs/common'
import { JwtService } from '@nestjs/jwt'
import { UserService } from '../user/user.service'

@Injectable()
export class AuthService {
  constructor(
    private jwtService: JwtService,
    private userService: UserService,
  ) {}

  async validateUser(userId: string, password: string): Promise<any> {
    const user = await this.userService.findByUsernameOrPhone(userId)
    
    if (!user) {
      return null
    }

    if (!user.is_active) {
      throw new UnauthorizedException('User account is inactive')
    }

    const isPasswordValid = await this.userService.validatePassword(
      password,
      user.password_hash,
    )

    if (!isPasswordValid) {
      return null
    }

    // Update last login
    await this.userService.updateLastLogin(user.id)

    // Return user without password
    const { password_hash, ...result } = user
    return {
      ...result,
      userId: user.username,
      name: `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username,
    }
  }

  async login(user: any) {
    const payload = { 
      userId: user.username, 
      sub: user.id,
      role: user.role,
    }
    
    return {
      token: this.jwtService.sign(payload),
      user: {
        id: user.id,
        userId: user.username,
        name: `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username,
        email: user.email,
        phone_number: user.phone_number,
        role: user.role,
      },
    }
  }
}
