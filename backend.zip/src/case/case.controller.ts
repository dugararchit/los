import {
  Controller,
  Get,
  Param,
  UseGuards,
  Request,
  Patch,
  Body,
  Query,
  ForbiddenException,
} from '@nestjs/common'
import { CaseService } from './case.service'
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard'
import { RolesGuard } from '../auth/guards/roles.guard'
import { Roles } from '../auth/decorators/roles.decorator'
import { UserRole, CaseStatus } from '../entities'

@Controller('cases')
@UseGuards(JwtAuthGuard, RolesGuard)
export class CaseController {
  constructor(private readonly caseService: CaseService) {}

  @Get()
  @Roles(UserRole.ADMIN, UserRole.USER, UserRole.MANAGER, UserRole.PRESIDENT)
  async findAll(@Request() req, @Query('status') status?: CaseStatus) {
    const user = req.user.user

    // Admin can see all cases
    if (user.role === UserRole.ADMIN) {
      if (status) {
        return this.caseService.findAllByStatus(status)
      }
      // Return all cases for admin (you might want to add pagination)
      return []
    }

    // Regular users see only their cases
    if (user.role === UserRole.USER) {
      return this.caseService.findAllByUser(user.id)
    }

    // Managers and Presidents see cases by status
    if (status) {
      return this.caseService.findAllByStatus(status)
    }

    return []
  }

  @Get(':id')
  @Roles(UserRole.ADMIN, UserRole.USER, UserRole.MANAGER, UserRole.PRESIDENT)
  async findOne(@Param('id') id: string, @Request() req) {
    const caseEntity = await this.caseService.findById(+id)
    const user = req.user.user

    // Users can only see their own cases unless they're admin/manager/president
    if (
      user.role === UserRole.USER &&
      caseEntity.created_by !== user.id
    ) {
      throw new ForbiddenException('You do not have permission to view this case')
    }

    return caseEntity
  }

  @Patch(':id/status')
  @Roles(UserRole.ADMIN, UserRole.MANAGER, UserRole.PRESIDENT)
  async updateStatus(
    @Param('id') id: string,
    @Body('status') status: CaseStatus,
    @Body('comments') comments: string,
    @Request() req,
  ) {
    return this.caseService.updateStatus(+id, status, req.user.user.id, comments)
  }
}
