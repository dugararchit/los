import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { Case } from '../entities/case.entity'
import { CaseStatusHistory } from '../entities/case-status-history.entity'
import { CaseService } from './case.service'
import { CaseController } from './case.controller'

@Module({
  imports: [TypeOrmModule.forFeature([Case, CaseStatusHistory])],
  controllers: [CaseController],
  providers: [CaseService],
  exports: [CaseService],
})
export class CaseModule {}
