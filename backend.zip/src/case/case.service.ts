import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common'
import { InjectRepository } from '@nestjs/typeorm'
import { Repository, DataSource } from 'typeorm'
import { Case, CaseStatus } from '../entities/case.entity'
import { CaseStatusHistory } from '../entities/case-status-history.entity'

@Injectable()
export class CaseService {
  constructor(
    @InjectRepository(Case)
    private caseRepository: Repository<Case>,
    @InjectRepository(CaseStatusHistory)
    private statusHistoryRepository: Repository<CaseStatusHistory>,
    private dataSource: DataSource,
  ) {}

  async findById(id: number): Promise<Case> {
    const caseEntity = await this.caseRepository.findOne({
      where: { id },
      relations: ['created_by_user', 'assigned_to_user', 'customer'],
    })
    if (!caseEntity) {
      throw new NotFoundException(`Case with ID ${id} not found`)
    }
    return caseEntity
  }

  async findByCaseNumber(caseNumber: string): Promise<Case> {
    const caseEntity = await this.caseRepository.findOne({
      where: { case_number: caseNumber },
      relations: ['created_by_user', 'assigned_to_user', 'customer'],
    })
    if (!caseEntity) {
      throw new NotFoundException(`Case with number ${caseNumber} not found`)
    }
    return caseEntity
  }

  async findAllByUser(userId: number): Promise<Case[]> {
    return this.caseRepository.find({
      where: { created_by: userId },
      relations: ['customer'],
      order: { created_at: 'DESC' },
    })
  }

  async findAllByStatus(status: CaseStatus): Promise<Case[]> {
    return this.caseRepository.find({
      where: { status },
      relations: ['created_by_user', 'customer'],
      order: { submitted_at: 'ASC' },
    })
  }

  async canEdit(caseId: number, userId: number): Promise<boolean> {
    const caseEntity = await this.findById(caseId)
    return (
      caseEntity.status === CaseStatus.INITIALIZED &&
      caseEntity.created_by === userId
    )
  }

  async updateStatus(
    caseId: number,
    newStatus: CaseStatus,
    userId: number,
    comments?: string,
  ): Promise<Case> {
    const caseEntity = await this.findById(caseId)
    const oldStatus = caseEntity.status

    // Validate status transition
    this.validateStatusTransition(oldStatus, newStatus, userId)

    const queryRunner = this.dataSource.createQueryRunner()
    await queryRunner.connect()
    await queryRunner.startTransaction()

    try {
      // Update case status
      caseEntity.status = newStatus
      if (newStatus === CaseStatus.MANAGER_APPROVAL && oldStatus === CaseStatus.INITIALIZED) {
        caseEntity.submitted_at = new Date()
      }
      if (newStatus === CaseStatus.FINAL_APPROVAL_DONE) {
        caseEntity.closed_at = new Date()
      }

      await queryRunner.manager.save(Case, caseEntity)

      // Create status history
      const statusHistory = queryRunner.manager.create(CaseStatusHistory, {
        case_id: caseId,
        from_status: oldStatus,
        to_status: newStatus,
        changed_by: userId,
        comments,
      })
      await queryRunner.manager.save(CaseStatusHistory, statusHistory)

      await queryRunner.commitTransaction()
      return caseEntity
    } catch (error) {
      await queryRunner.rollbackTransaction()
      throw error
    } finally {
      await queryRunner.release()
    }
  }

  private validateStatusTransition(
    oldStatus: CaseStatus,
    newStatus: CaseStatus,
    userId: number,
  ): void {
    // Add validation logic based on roles and status transitions
    // This is a simplified version - you can expand based on requirements
    const validTransitions: Record<CaseStatus, CaseStatus[]> = {
      [CaseStatus.INITIALIZED]: [CaseStatus.MANAGER_APPROVAL, CaseStatus.CANCELLED],
      [CaseStatus.MANAGER_APPROVAL]: [
        CaseStatus.PRESIDENT_APPROVAL,
        CaseStatus.REJECTED,
        CaseStatus.CANCELLED,
      ],
      [CaseStatus.PRESIDENT_APPROVAL]: [
        CaseStatus.FINAL_APPROVAL_DONE,
        CaseStatus.REJECTED,
        CaseStatus.CANCELLED,
      ],
      [CaseStatus.FINAL_APPROVAL_DONE]: [],
      [CaseStatus.REJECTED]: [CaseStatus.CANCELLED],
      [CaseStatus.CANCELLED]: [],
    }

    if (!validTransitions[oldStatus]?.includes(newStatus)) {
      throw new ForbiddenException(
        `Invalid status transition from ${oldStatus} to ${newStatus}`,
      )
    }
  }
}
