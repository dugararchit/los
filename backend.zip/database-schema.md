# Database Schema Design

## Overview
This document outlines the PostgreSQL database schema for the STATUS Leasing and Finance application. The schema is designed to handle user management, case tracking, customer information, and document management.

## Database Tables

### 1. **users** Table
Stores system users who can create cases/forms.

```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone_number VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'user', -- 'admin', 'user', 'manager', 'president', 'approver'
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_phone ON users(phone_number);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

**Notes:**
- Phone number is the primary identifier (as requested)
- Role-based access control with enum-like values
- Tracks last login for security
- Soft delete capability with `is_active`

---

### 2. **cases** Table
Each form submission becomes a case. Links to the user who created it.

```sql
CREATE TABLE cases (
    id SERIAL PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL, -- Auto-generated: CASE-YYYYMMDD-XXXX
    created_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    case_type VARCHAR(50) NOT NULL DEFAULT 'customer_registration', -- 'customer_registration', 'loan_application', etc.
    status VARCHAR(50) NOT NULL DEFAULT 'initialized', -- 'initialized', 'manager_approval', 'president_approval', 'final_approval_done', 'rejected', 'cancelled'
    priority VARCHAR(20) DEFAULT 'normal', -- 'low', 'normal', 'high', 'urgent'
    notes TEXT,
    assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL, -- For case assignment
    submitted_at TIMESTAMP,
    closed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_cases_created_by ON cases(created_by);
CREATE INDEX idx_cases_status ON cases(status);
CREATE INDEX idx_cases_case_number ON cases(case_number);
CREATE INDEX idx_cases_assigned_to ON cases(assigned_to);
```

**Notes:**
- `created_by` links to the user who filed the case
- Case number for easy reference
- Status workflow: initialized → manager_approval → president_approval → final_approval_done
- Once status moves from 'initialized', the creator has read-only access
- Assignment capability for team collaboration
- `submitted_at` tracks when case moves from 'initialized' to 'manager_approval'

---

### 3. **customers** Table
Stores customer information from the form. **Each form submission (case) contains complete customer details.**

**Design Philosophy:**
- **One case = One customer record** (1:1 relationship)
- Customer data is stored as a **snapshot** at the time of case creation
- Each case is independent - if the same person applies again, a new case with new customer record is created
- Customer data is tightly coupled with the case (they're created together)

```sql
CREATE TABLE customers (
    id SERIAL PRIMARY KEY,
    case_id INTEGER NOT NULL UNIQUE REFERENCES cases(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL DEFAULT 'Individual', -- 'Individual', 'Corporate', etc.
    
    -- Personal Information
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    relation VARCHAR(50), -- 'self', 'father', 'mother', 'spouse', etc.
    relation_first_name VARCHAR(100),
    relation_last_name VARCHAR(100),
    customer_photo_url VARCHAR(500), -- Path to uploaded photo
    
    -- Demographics
    gender VARCHAR(20) NOT NULL,
    date_of_birth DATE NOT NULL,
    age INTEGER,
    marital_status VARCHAR(20) NOT NULL,
    customer_religion VARCHAR(50),
    customer_caste VARCHAR(50),
    
    -- Contact Information (used to identify returning customers)
    primary_contact_no VARCHAR(20) NOT NULL,
    alternate_no VARCHAR(20),
    email VARCHAR(255),
    other_email_id VARCHAR(255),
    whatsapp_no VARCHAR(20),
    
    -- Professional Information
    customer_profile VARCHAR(100), -- 'salaried', 'business', 'professional', etc.
    customer_category VARCHAR(100),
    sub_category VARCHAR(100),
    nature_of_work VARCHAR(100),
    business_type VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_customers_case_id ON customers(case_id);
CREATE INDEX idx_customers_primary_contact ON customers(primary_contact_no);
CREATE INDEX idx_customers_email ON customers(email);
CREATE INDEX idx_customers_dob ON customers(date_of_birth);
```

**Notes:**
- **UNIQUE constraint on case_id**: Ensures one customer record per case
- **Customer data = Case data**: When a form is filled, it creates both a case and customer record together
- **Returning customers**: Query by `primary_contact_no` or `email` to find all cases for the same person
- **Data snapshot**: Customer information is frozen at case creation time (even if person's details change later)
- Photo stored as URL reference to documents table

---

### 4. **addresses** Table
Stores all addresses (present, permanent, work) for customers. Normalized design.

```sql
CREATE TABLE addresses (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    address_type VARCHAR(20) NOT NULL, -- 'present', 'permanent', 'work'
    address_line TEXT NOT NULL,
    landmark VARCHAR(255),
    pincode VARCHAR(10) NOT NULL,
    state VARCHAR(100) NOT NULL,
    district VARCHAR(100) NOT NULL,
    tehsil VARCHAR(100) NOT NULL,
    no_of_years VARCHAR(50),
    rent_own VARCHAR(20), -- 'rent', 'own'
    distance_to_branch VARCHAR(50),
    is_communication_address BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(customer_id, address_type) -- One address per type per customer
);

CREATE INDEX idx_addresses_customer_id ON addresses(customer_id);
CREATE INDEX idx_addresses_type ON addresses(address_type);
```

**Notes:**
- Normalized to avoid duplication
- Unique constraint ensures one address per type per customer
- Can easily query by address type

---

### 5. **kyc_documents** Table
Stores KYC document information. Multiple documents per customer.

```sql
CREATE TABLE kyc_documents (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    document_type VARCHAR(100) NOT NULL, -- 'aadhaar', 'pan', 'passport', 'driving_license', 'voter_id', etc.
    document_number VARCHAR(100) NOT NULL,
    document_url VARCHAR(500), -- Path to uploaded document (front)
    document_url_back VARCHAR(500), -- Path to uploaded document (back, if applicable)
    verification_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    verified_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_kyc_documents_customer_id ON kyc_documents(customer_id);
CREATE INDEX idx_kyc_documents_type ON kyc_documents(document_type);
CREATE INDEX idx_kyc_documents_number ON kyc_documents(document_number);
```

**Notes:**
- Supports front and back images for documents
- Verification workflow built-in
- Document URLs reference the documents table

---

### 6. **bank_details** Table
Stores bank account information. Multiple accounts per customer.

```sql
CREATE TABLE bank_details (
    id SERIAL PRIMARY KEY,
    customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    beneficiary VARCHAR(255) NOT NULL,
    account_number VARCHAR(50) NOT NULL,
    bank_name VARCHAR(255) NOT NULL,
    bank_branch VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- 'savings', 'current', 'salary', etc.
    ifsc_code VARCHAR(20) NOT NULL,
    micr_code VARCHAR(20),
    is_primary BOOLEAN DEFAULT false, -- Mark primary account
    verification_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    verified_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bank_details_customer_id ON bank_details(customer_id);
CREATE INDEX idx_bank_details_account_number ON bank_details(account_number);
CREATE INDEX idx_bank_details_ifsc ON bank_details(ifsc_code);
```

**Notes:**
- Multiple bank accounts supported
- Primary account flag for easy identification
- Verification workflow included

---

### 7. **documents** Table
Centralized document storage. Stores all uploaded files (photos, KYC docs, etc.).

```sql
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    case_id INTEGER REFERENCES cases(id) ON DELETE CASCADE,
    customer_id INTEGER REFERENCES customers(id) ON DELETE CASCADE,
    document_type VARCHAR(100) NOT NULL, -- 'customer_photo', 'kyc_document', 'bank_statement', 'other'
    file_name VARCHAR(255) NOT NULL,
    original_file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL, -- Storage path
    file_size BIGINT NOT NULL, -- Size in bytes
    mime_type VARCHAR(100), -- 'image/jpeg', 'application/pdf', etc.
    upload_type VARCHAR(50), -- 'front', 'back', 'single'
    uploaded_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_documents_case_id ON documents(case_id);
CREATE INDEX idx_documents_customer_id ON documents(customer_id);
CREATE INDEX idx_documents_type ON documents(document_type);
CREATE INDEX idx_documents_uploaded_by ON documents(uploaded_by);
```

**Notes:**
- Centralized document management
- Links to both case and customer for flexibility
- Tracks file metadata (size, type, etc.)
- Can store any type of document

---

### 8. **case_status_history** Table
Tracks all status changes and transitions for audit purposes.

```sql
CREATE TABLE case_status_history (
    id SERIAL PRIMARY KEY,
    case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    from_status VARCHAR(50), -- Previous status (NULL for initial status)
    to_status VARCHAR(50) NOT NULL, -- New status
    changed_by INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    comments TEXT, -- Optional comments/reason for status change
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_case_status_history_case_id ON case_status_history(case_id);
CREATE INDEX idx_case_status_history_changed_by ON case_status_history(changed_by);
CREATE INDEX idx_case_status_history_to_status ON case_status_history(to_status);
CREATE INDEX idx_case_status_history_created_at ON case_status_history(created_at);
```

**Notes:**
- Complete audit trail of all status transitions
- Tracks who made the change and when
- Allows querying status change history for any case
- `from_status` is NULL for the initial 'initialized' status

---

### 9. **case_notes** Table (Optional)
For tracking case comments and general notes.

```sql
CREATE TABLE case_notes (
    id SERIAL PRIMARY KEY,
    case_id INTEGER NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    note_type VARCHAR(50) DEFAULT 'comment', -- 'comment', 'assignment', 'system', 'rejection_reason'
    note_text TEXT NOT NULL,
    is_internal BOOLEAN DEFAULT false, -- Internal notes not visible to creator
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_case_notes_case_id ON case_notes(case_id);
CREATE INDEX idx_case_notes_user_id ON case_notes(user_id);
CREATE INDEX idx_case_notes_note_type ON case_notes(note_type);
```

**Notes:**
- General comments and notes on cases
- Separate from status history for flexibility
- Internal notes can be hidden from case creator

---

## Relationships Summary

```
users (1) ──→ (many) cases [created_by]
users (1) ──→ (many) cases [assigned_to]
cases (1) ──→ (1) customers [ONE-TO-ONE: Each case has exactly one customer record]
customers (1) ──→ (many) addresses
customers (1) ──→ (many) kyc_documents
customers (1) ──→ (many) bank_details
cases (1) ──→ (many) documents
customers (1) ──→ (many) documents
cases (1) ──→ (many) case_status_history
cases (1) ──→ (many) case_notes
```

## Customer-Case Relationship Explained

### Key Concept: **Customer Data IS Case Data**

**How it works:**
1. User fills the customer form → Creates a **case** (status: 'initialized')
2. Case creation automatically creates a **customer** record with all form data
3. They are created together and live together (1:1 relationship)
4. **Every form submission = One case = One customer record**

**Example Flow:**
```
User fills form → Case created (CASE-001) → Customer record created (linked to CASE-001)
  - Case has: case_number, status, created_by
  - Customer has: first_name, phone, email, addresses, documents, etc.
  - Together they represent ONE complete application
```

**Handling Returning Customers:**
- Same person (same phone/email) can submit multiple forms
- Each submission = New case = New customer record
- To find all cases for a person: Query by `primary_contact_no` or `email`
- Each case maintains its own snapshot of customer data at submission time

**Benefits:**
- ✅ Complete data isolation per case
- ✅ Historical data preserved (can see how customer details changed over time)
- ✅ Easy to query all cases for a customer
- ✅ No data conflicts between cases
- ✅ Simple relationship model (no complex joins needed)

---

## Key Design Decisions

1. **Normalized Addresses**: Addresses are stored in a separate table to avoid duplication and allow easy querying by type.

2. **Case-Centric Design**: Every form submission is a case, making it easy to track workflow and status.

3. **Centralized Documents**: All documents stored in one table with references to both cases and customers for flexibility.

4. **User Roles**: Simple role-based system that can be extended with a roles/permissions table if needed later.

5. **Verification Workflows**: Built-in verification status for KYC documents and bank details.

6. **Audit Trail**: Created/updated timestamps on all tables, plus case_status_history for complete status tracking.

7. **Workflow Management**: Status-based workflow with enforced transitions (initialized → manager_approval → president_approval → final_approval_done).

8. **Read-Only Access**: Once a case moves from 'initialized' status, the creator loses edit access (enforced at application level).

---

## Sample Queries

### Get all cases created by a user
```sql
SELECT c.*, u.username, u.phone_number 
FROM cases c
JOIN users u ON c.created_by = u.id
WHERE c.created_by = :userId;
```

### Get complete customer information with addresses
```sql
SELECT 
    c.*,
    json_agg(
        json_build_object(
            'type', a.address_type,
            'address', a.address_line,
            'state', a.state,
            'district', a.district
        )
    ) as addresses
FROM customers c
LEFT JOIN addresses a ON c.id = a.customer_id
WHERE c.case_id = :caseId
GROUP BY c.id;
```

### Get all documents for a case
```sql
SELECT d.*, u.username as uploaded_by_name
FROM documents d
LEFT JOIN users u ON d.uploaded_by = u.id
WHERE d.case_id = :caseId;
```

### Get complete status history for a case
```sql
SELECT 
    csh.*,
    u.username as changed_by_name,
    u.role as changed_by_role
FROM case_status_history csh
JOIN users u ON csh.changed_by = u.id
WHERE csh.case_id = :caseId
ORDER BY csh.created_at ASC;
```

### Check if user can edit a case (application logic)
```sql
-- Returns true if case is still in 'initialized' status and user is the creator
SELECT 
    CASE 
        WHEN c.status = 'initialized' AND c.created_by = :userId THEN true
        ELSE false
    END as can_edit
FROM cases c
WHERE c.id = :caseId;
```

### Get cases pending manager approval
```sql
SELECT c.*, u.username as created_by_name, u.phone_number as created_by_phone
FROM cases c
JOIN users u ON c.created_by = u.id
WHERE c.status = 'manager_approval'
ORDER BY c.submitted_at ASC;
```

### Get cases pending president approval
```sql
SELECT c.*, u.username as created_by_name, u.phone_number as created_by_phone
FROM cases c
JOIN users u ON c.created_by = u.id
WHERE c.status = 'president_approval'
ORDER BY c.submitted_at ASC;
```

### Find all cases for a customer (by phone number)
```sql
SELECT 
    c.*,
    cust.first_name,
    cust.last_name,
    cust.email,
    c.status,
    c.created_at
FROM cases c
JOIN customers cust ON c.id = cust.case_id
WHERE cust.primary_contact_no = :phoneNumber
ORDER BY c.created_at DESC;
```

### Find all cases for a customer (by email)
```sql
SELECT 
    c.*,
    cust.first_name,
    cust.last_name,
    cust.primary_contact_no,
    c.status,
    c.created_at
FROM cases c
JOIN customers cust ON c.id = cust.case_id
WHERE cust.email = :email OR cust.other_email_id = :email
ORDER BY c.created_at DESC;
```

### Get complete case with all customer details
```sql
SELECT 
    c.id as case_id,
    c.case_number,
    c.status,
    c.created_at as case_created_at,
    cust.*,
    json_agg(
        DISTINCT jsonb_build_object(
            'type', a.address_type,
            'address', a.address_line,
            'state', a.state,
            'district', a.district,
            'pincode', a.pincode
        )
    ) as addresses,
    json_agg(
        DISTINCT jsonb_build_object(
            'type', kd.document_type,
            'number', kd.document_number,
            'status', kd.verification_status
        )
    ) as kyc_documents,
    json_agg(
        DISTINCT jsonb_build_object(
            'bank_name', bd.bank_name,
            'account_number', bd.account_number,
            'ifsc', bd.ifsc_code,
            'is_primary', bd.is_primary
        )
    ) as bank_details
FROM cases c
JOIN customers cust ON c.id = cust.case_id
LEFT JOIN addresses a ON cust.id = a.customer_id
LEFT JOIN kyc_documents kd ON cust.id = kd.customer_id
LEFT JOIN bank_details bd ON cust.id = bd.customer_id
WHERE c.id = :caseId
GROUP BY c.id, cust.id;
```

---

## Workflow Status Transitions

### Status Flow
```
initialized → manager_approval → president_approval → final_approval_done
     ↓              ↓                    ↓
  rejected      rejected            rejected
     ↓              ↓                    ↓
  cancelled    cancelled          cancelled
```

### Status Definitions
- **initialized**: Case is created and being filled by the creator (editable)
- **manager_approval**: Case submitted, awaiting manager review (creator read-only)
- **president_approval**: Manager approved, awaiting president review (creator read-only)
- **final_approval_done**: All approvals completed, case finalized (creator read-only)
- **rejected**: Case rejected at any stage (can be reopened or cancelled)
- **cancelled**: Case cancelled/withdrawn (final state)

### Access Control Rules
1. **Case Creator**: Can edit only when status is 'initialized'
2. **Manager Role**: Can approve/reject cases in 'manager_approval' status
3. **President Role**: Can approve/reject cases in 'president_approval' status
4. **Admin Role**: Can view all cases and override status if needed

### Status Change Logic
- Every status change must be recorded in `case_status_history`
- When moving from 'initialized' to 'manager_approval', set `submitted_at` timestamp
- When reaching 'final_approval_done', set `closed_at` timestamp
- Rejections can happen at any approval stage
- Rejected cases can be reopened (status back to previous stage) or cancelled

---

## Next Steps

1. Review and approve the schema
2. Set up database connection in NestJS
3. Create entity models (TypeORM/Prisma)
4. Implement repositories/services
5. Implement workflow guards and status transition logic
6. Add read-only access middleware/guards for case editing
