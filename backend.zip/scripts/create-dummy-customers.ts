import { DataSource } from 'typeorm'
import * as dotenv from 'dotenv'
import * as path from 'path'
import {
  User,
  Case,
  CaseStatus,
  CaseType,
  Priority,
  Customer,
  Address,
  AddressType,
  KycDocument,
  VerificationStatus,
  BankDetail,
  Document,
  CaseStatusHistory,
  CaseNote,
} from '../src/entities'

// Load environment variables
dotenv.config({ path: path.join(__dirname, '../.env') })

async function createDummyCustomers() {
  const dataSource = new DataSource({
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    username: process.env.DB_USERNAME || 'postgres',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'auth_database',
    entities: [
      User,
      Case,
      Customer,
      Address,
      KycDocument,
      BankDetail,
      Document,
      CaseStatusHistory,
      CaseNote,
    ],
    synchronize: false,
  })

  try {
    await dataSource.initialize()
    console.log('Database connected successfully')

    const userRepository = dataSource.getRepository(User)
    const caseRepository = dataSource.getRepository(Case)
    const customerRepository = dataSource.getRepository(Customer)
    const addressRepository = dataSource.getRepository(Address)
    const kycRepository = dataSource.getRepository(KycDocument)
    const bankRepository = dataSource.getRepository(BankDetail)

    // Get a user to assign cases to (admin1)
    const user = await userRepository.findOne({ where: { username: 'admin1' } })
    if (!user) {
      throw new Error('User admin1 not found. Please create users first.')
    }

    const dummyCustomers = [
      {
        customer: {
          type: 'Individual',
          first_name: 'Rajesh',
          last_name: 'Kumar',
          relation: 'self',
          relation_first_name: 'Rajesh',
          relation_last_name: 'Kumar',
          gender: 'Male',
          date_of_birth: new Date('1985-05-15'),
          age: 39,
          marital_status: 'Married',
          customer_religion: 'Hindu',
          customer_caste: 'General',
          primary_contact_no: '9876543210',
          alternate_no: '9876543211',
          email: 'rajesh.kumar@example.com',
          other_email_id: 'rajesh.personal@example.com',
          whatsapp_no: '9876543210',
          customer_profile: 'Salaried',
          customer_category: 'Category 1',
          sub_category: 'Sub-Category 1',
          nature_of_work: 'Salaried',
          business_type: 'Type 1',
        },
        case: {
          case_type: CaseType.CUSTOMER_REGISTRATION,
          status: CaseStatus.INITIALIZED,
          priority: Priority.NORMAL,
        },
        addresses: [
          {
            address_type: AddressType.PRESENT,
            address_line: '123, MG Road, Near City Mall',
            landmark: 'City Mall',
            pincode: '560001',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore North',
            no_of_years: '5',
            rent_own: 'Own',
            distance_to_branch: '2.5',
            is_communication_address: true,
          },
          {
            address_type: AddressType.PERMANENT,
            address_line: '123, MG Road, Near City Mall',
            landmark: 'City Mall',
            pincode: '560001',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore North',
            no_of_years: '10',
            rent_own: 'Own',
            distance_to_branch: '2.5',
            is_communication_address: false,
          },
        ],
        kycDocuments: [
          {
            document_type: 'Aadhaar',
            document_number: '1234 5678 9012',
            verification_status: VerificationStatus.PENDING,
          },
          {
            document_type: 'PAN',
            document_number: 'ABCDE1234F',
            verification_status: VerificationStatus.PENDING,
          },
        ],
        bankDetails: [
          {
            beneficiary: 'Rajesh Kumar',
            account_number: '1234567890123456',
            bank_name: 'State Bank of India',
            bank_branch: 'MG Road Branch',
            account_type: 'Savings',
            ifsc_code: 'SBIN0001234',
            micr_code: '560002001',
            is_primary: true,
            verification_status: VerificationStatus.PENDING,
          },
        ],
      },
      {
        customer: {
          type: 'Individual',
          first_name: 'Priya',
          last_name: 'Sharma',
          relation: 'self',
          relation_first_name: 'Priya',
          relation_last_name: 'Sharma',
          gender: 'Female',
          date_of_birth: new Date('1990-08-22'),
          age: 34,
          marital_status: 'Single',
          customer_religion: 'Hindu',
          customer_caste: 'OBC',
          primary_contact_no: '9876543220',
          alternate_no: '9876543221',
          email: 'priya.sharma@example.com',
          whatsapp_no: '9876543220',
          customer_profile: 'Business',
          customer_category: 'Category 2',
          sub_category: 'Sub-Category 2',
          nature_of_work: 'Business',
          business_type: 'Type 2',
        },
        case: {
          case_type: CaseType.CUSTOMER_REGISTRATION,
          status: CaseStatus.MANAGER_APPROVAL,
          priority: Priority.HIGH,
        },
        addresses: [
          {
            address_type: AddressType.PRESENT,
            address_line: '456, Commercial Street',
            landmark: 'Near Metro Station',
            pincode: '560002',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore Central',
            no_of_years: '3',
            rent_own: 'Rent',
            distance_to_branch: '5.0',
            is_communication_address: true,
          },
          {
            address_type: AddressType.PERMANENT,
            address_line: '789, Village Road, Hometown',
            landmark: 'Near Temple',
            pincode: '123456',
            state: 'Rajasthan',
            district: 'Jaipur',
            tehsil: 'Jaipur Central',
            no_of_years: '25',
            rent_own: 'Own',
            distance_to_branch: '150.0',
            is_communication_address: false,
          },
        ],
        kycDocuments: [
          {
            document_type: 'Aadhaar',
            document_number: '2345 6789 0123',
            verification_status: VerificationStatus.VERIFIED,
          },
          {
            document_type: 'PAN',
            document_number: 'FGHIJ5678K',
            verification_status: VerificationStatus.VERIFIED,
          },
          {
            document_type: 'Passport',
            document_number: 'P1234567',
            verification_status: VerificationStatus.PENDING,
          },
        ],
        bankDetails: [
          {
            beneficiary: 'Priya Sharma',
            account_number: '2345678901234567',
            bank_name: 'HDFC Bank',
            bank_branch: 'Commercial Street Branch',
            account_type: 'Current',
            ifsc_code: 'HDFC0002345',
            micr_code: '560002002',
            is_primary: true,
            verification_status: VerificationStatus.VERIFIED,
          },
        ],
      },
      {
        customer: {
          type: 'Individual',
          first_name: 'Amit',
          last_name: 'Patel',
          relation: 'self',
          relation_first_name: 'Amit',
          relation_last_name: 'Patel',
          gender: 'Male',
          date_of_birth: new Date('1988-12-10'),
          age: 36,
          marital_status: 'Married',
          customer_religion: 'Hindu',
          customer_caste: 'General',
          primary_contact_no: '9876543230',
          email: 'amit.patel@example.com',
          whatsapp_no: '9876543230',
          customer_profile: 'Professional',
          customer_category: 'Category 1',
          sub_category: 'Sub-Category 3',
          nature_of_work: 'Self-Employed',
          business_type: 'Type 3',
        },
        case: {
          case_type: CaseType.CUSTOMER_REGISTRATION,
          status: CaseStatus.PRESIDENT_APPROVAL,
          priority: Priority.NORMAL,
        },
        addresses: [
          {
            address_type: AddressType.PRESENT,
            address_line: '789, Indira Nagar',
            landmark: 'Near Park',
            pincode: '560038',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore East',
            no_of_years: '7',
            rent_own: 'Own',
            distance_to_branch: '8.0',
            is_communication_address: true,
          },
          {
            address_type: AddressType.PERMANENT,
            address_line: '789, Indira Nagar',
            landmark: 'Near Park',
            pincode: '560038',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore East',
            no_of_years: '7',
            rent_own: 'Own',
            distance_to_branch: '8.0',
            is_communication_address: false,
          },
          {
            address_type: AddressType.WORK,
            address_line: '321, IT Park, Whitefield',
            landmark: 'Near Tech Park',
            pincode: '560066',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore East',
            no_of_years: '2',
            rent_own: 'Rent',
            distance_to_branch: '15.0',
            is_communication_address: false,
          },
        ],
        kycDocuments: [
          {
            document_type: 'Aadhaar',
            document_number: '3456 7890 1234',
            verification_status: VerificationStatus.VERIFIED,
          },
          {
            document_type: 'PAN',
            document_number: 'KLMNO9012P',
            verification_status: VerificationStatus.VERIFIED,
          },
        ],
        bankDetails: [
          {
            beneficiary: 'Amit Patel',
            account_number: '3456789012345678',
            bank_name: 'ICICI Bank',
            bank_branch: 'Indira Nagar Branch',
            account_type: 'Savings',
            ifsc_code: 'ICIC0003456',
            micr_code: '560002003',
            is_primary: true,
            verification_status: VerificationStatus.VERIFIED,
          },
          {
            beneficiary: 'Amit Patel',
            account_number: '3456789012345679',
            bank_name: 'Axis Bank',
            bank_branch: 'Whitefield Branch',
            account_type: 'Salary',
            ifsc_code: 'UTIB0004567',
            micr_code: '560002004',
            is_primary: false,
            verification_status: VerificationStatus.PENDING,
          },
        ],
      },
      {
        customer: {
          type: 'Individual',
          first_name: 'Sunita',
          last_name: 'Reddy',
          relation: 'self',
          relation_first_name: 'Sunita',
          relation_last_name: 'Reddy',
          gender: 'Female',
          date_of_birth: new Date('1992-03-18'),
          age: 32,
          marital_status: 'Married',
          customer_religion: 'Hindu',
          customer_caste: 'General',
          primary_contact_no: '9876543240',
          alternate_no: '9876543241',
          email: 'sunita.reddy@example.com',
          whatsapp_no: '9876543240',
          customer_profile: 'Salaried',
          customer_category: 'Category 1',
          sub_category: 'Sub-Category 1',
          nature_of_work: 'Salaried',
          business_type: 'Type 1',
        },
        case: {
          case_type: CaseType.CUSTOMER_REGISTRATION,
          status: CaseStatus.FINAL_APPROVAL_DONE,
          priority: Priority.NORMAL,
        },
        addresses: [
          {
            address_type: AddressType.PRESENT,
            address_line: '654, Koramangala 5th Block',
            landmark: 'Near Forum Mall',
            pincode: '560095',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore South',
            no_of_years: '4',
            rent_own: 'Rent',
            distance_to_branch: '6.5',
            is_communication_address: true,
          },
          {
            address_type: AddressType.PERMANENT,
            address_line: '321, Main Street, Hyderabad',
            landmark: 'Near Bus Stand',
            pincode: '500001',
            state: 'Telangana',
            district: 'Hyderabad',
            tehsil: 'Hyderabad Central',
            no_of_years: '30',
            rent_own: 'Own',
            distance_to_branch: '600.0',
            is_communication_address: false,
          },
        ],
        kycDocuments: [
          {
            document_type: 'Aadhaar',
            document_number: '4567 8901 2345',
            verification_status: VerificationStatus.VERIFIED,
          },
          {
            document_type: 'PAN',
            document_number: 'PQRST1234U',
            verification_status: VerificationStatus.VERIFIED,
          },
          {
            document_type: 'Voter ID',
            document_number: 'VOT123456789',
            verification_status: VerificationStatus.VERIFIED,
          },
        ],
        bankDetails: [
          {
            beneficiary: 'Sunita Reddy',
            account_number: '4567890123456789',
            bank_name: 'Kotak Mahindra Bank',
            bank_branch: 'Koramangala Branch',
            account_type: 'Savings',
            ifsc_code: 'KKBK0005678',
            micr_code: '560002005',
            is_primary: true,
            verification_status: VerificationStatus.VERIFIED,
          },
        ],
      },
      {
        customer: {
          type: 'Individual',
          first_name: 'Vikram',
          last_name: 'Singh',
          relation: 'self',
          relation_first_name: 'Vikram',
          relation_last_name: 'Singh',
          gender: 'Male',
          date_of_birth: new Date('1987-07-25'),
          age: 37,
          marital_status: 'Married',
          customer_religion: 'Sikh',
          customer_caste: 'General',
          primary_contact_no: '9876543250',
          email: 'vikram.singh@example.com',
          whatsapp_no: '9876543250',
          customer_profile: 'Business',
          customer_category: 'Category 3',
          sub_category: 'Sub-Category 1',
          nature_of_work: 'Business',
          business_type: 'Type 2',
        },
        case: {
          case_type: CaseType.CUSTOMER_REGISTRATION,
          status: CaseStatus.REJECTED,
          priority: Priority.LOW,
        },
        addresses: [
          {
            address_type: AddressType.PRESENT,
            address_line: '987, Jayanagar 4th Block',
            landmark: 'Near Shopping Complex',
            pincode: '560011',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore South',
            no_of_years: '6',
            rent_own: 'Own',
            distance_to_branch: '4.0',
            is_communication_address: true,
          },
          {
            address_type: AddressType.PERMANENT,
            address_line: '987, Jayanagar 4th Block',
            landmark: 'Near Shopping Complex',
            pincode: '560011',
            state: 'Karnataka',
            district: 'Bangalore',
            tehsil: 'Bangalore South',
            no_of_years: '6',
            rent_own: 'Own',
            distance_to_branch: '4.0',
            is_communication_address: false,
          },
        ],
        kycDocuments: [
          {
            document_type: 'Aadhaar',
            document_number: '5678 9012 3456',
            verification_status: VerificationStatus.REJECTED,
          },
          {
            document_type: 'PAN',
            document_number: 'UVWXY5678Z',
            verification_status: VerificationStatus.PENDING,
          },
        ],
        bankDetails: [
          {
            beneficiary: 'Vikram Singh',
            account_number: '5678901234567890',
            bank_name: 'Punjab National Bank',
            bank_branch: 'Jayanagar Branch',
            account_type: 'Current',
            ifsc_code: 'PUNB0006789',
            micr_code: '560002006',
            is_primary: true,
            verification_status: VerificationStatus.REJECTED,
          },
        ],
      },
    ]

    // Get count of existing cases for today to generate unique case numbers
    const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '')
    const existingCasesCount = await caseRepository
      .createQueryBuilder('case')
      .where('case.case_number LIKE :pattern', { pattern: `CASE-${datePart}-%` })
      .getCount()

    for (let i = 0; i < dummyCustomers.length; i++) {
      const data = dummyCustomers[i]
      const queryRunner = dataSource.createQueryRunner()
      await queryRunner.connect()
      await queryRunner.startTransaction()

      try {
        // Generate unique case number
        const sequenceNum = existingCasesCount + i + 1
        const caseNumber = `CASE-${datePart}-${String(sequenceNum).padStart(4, '0')}`

        // Create case
        const caseEntity = queryRunner.manager.create(Case, {
          case_number: caseNumber,
          created_by: user.id,
          ...data.case,
        })
        const savedCase = await queryRunner.manager.save(Case, caseEntity)

        // Create customer
        const customer = queryRunner.manager.create(Customer, {
          case_id: savedCase.id,
          ...data.customer,
        })
        const savedCustomer = await queryRunner.manager.save(Customer, customer)

        // Create addresses
        const addresses = data.addresses.map((addr) =>
          queryRunner.manager.create(Address, {
            customer_id: savedCustomer.id,
            ...addr,
          }),
        )
        await queryRunner.manager.save(Address, addresses)

        // Create KYC documents
        if (data.kycDocuments && data.kycDocuments.length > 0) {
          const kycDocs = data.kycDocuments.map((kyc) =>
            queryRunner.manager.create(KycDocument, {
              customer_id: savedCustomer.id,
              ...kyc,
            }),
          )
          await queryRunner.manager.save(KycDocument, kycDocs)
        }

        // Create bank details
        if (data.bankDetails && data.bankDetails.length > 0) {
          const bankDetails = data.bankDetails.map((bank) =>
            queryRunner.manager.create(BankDetail, {
              customer_id: savedCustomer.id,
              ...bank,
            }),
          )
          await queryRunner.manager.save(BankDetail, bankDetails)
        }

        await queryRunner.commitTransaction()
        console.log(
          `✓ Created customer: ${data.customer.first_name} ${data.customer.last_name} (Case: ${savedCase.case_number}, Status: ${savedCase.status})`,
        )
      } catch (error) {
        await queryRunner.rollbackTransaction()
        console.error(
          `✗ Failed to create customer ${data.customer.first_name}:`,
          error.message,
        )
      } finally {
        await queryRunner.release()
      }
    }

    console.log('\nAll dummy customers created successfully!')
  } catch (error) {
    console.error('Error creating customers:', error)
    process.exit(1)
  } finally {
    await dataSource.destroy()
  }
}

createDummyCustomers()
