import { DataSource } from 'typeorm'
import * as bcrypt from 'bcrypt'
import * as dotenv from 'dotenv'
import * as path from 'path'
import {
  User,
  UserRole,
  Case,
  Customer,
  Address,
  KycDocument,
  BankDetail,
  Document,
  CaseStatusHistory,
  CaseNote,
} from '../src/entities'

// Load environment variables
dotenv.config({ path: path.join(__dirname, '../.env') })

async function createDummyUsers() {
  const dataSource = new DataSource({
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    username: process.env.DB_USERNAME || 'postgres',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'auth_database',
    entities: [
      User,
      Case,
      Customer,
      Address,
      KycDocument,
      BankDetail,
      Document,
      CaseStatusHistory,
      CaseNote,
    ],
    synchronize: false,
  })

  try {
    await dataSource.initialize()
    console.log('Database connected successfully')

    const userRepository = dataSource.getRepository(User)

    // Hash password
    const passwordHash = await bcrypt.hash('admin123', 10)

    // Create users with different roles
    const users = [
      {
        username: 'admin1',
        phone_number: '1234567890',
        email: 'admin1@example.com',
        password_hash: passwordHash,
        role: UserRole.ADMIN,
        first_name: 'Admin',
        last_name: 'One',
        is_active: true,
      },
      {
        username: 'admin2',
        phone_number: '1234567891',
        email: 'admin2@example.com',
        password_hash: passwordHash,
        role: UserRole.MANAGER,
        first_name: 'Manager',
        last_name: 'Two',
        is_active: true,
      },
      {
        username: 'admin3',
        phone_number: '1234567892',
        email: 'admin3@example.com',
        password_hash: passwordHash,
        role: UserRole.USER,
        first_name: 'User',
        last_name: 'Three',
        is_active: true,
      },
    ]

    for (const userData of users) {
      // Check if user already exists
      const existingUser = await userRepository.findOne({
        where: [
          { username: userData.username },
          { phone_number: userData.phone_number },
        ],
      })

      if (existingUser) {
        console.log(`User ${userData.username} already exists, skipping...`)
        continue
      }

      const user = userRepository.create(userData)
      await userRepository.save(user)
      console.log(`✓ Created user: ${userData.username} (${userData.role})`)
    }

    console.log('\nAll dummy users created successfully!')
    console.log('\nLogin credentials:')
    console.log('Username: admin1 | Password: admin123 | Role: ADMIN')
    console.log('Username: admin2 | Password: admin123 | Role: MANAGER')
    console.log('Username: admin3 | Password: admin123 | Role: USER')
  } catch (error) {
    console.error('Error creating users:', error)
    process.exit(1)
  } finally {
    await dataSource.destroy()
  }
}

createDummyUsers()
