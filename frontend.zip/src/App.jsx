import { Routes, Route, Navigate } from 'react-router-dom'
import { useSelector } from 'react-redux'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import CustomerInfo from './pages/CustomerInfo'
import AddCustomer from './pages/AddCustomer'
import ViewCustomer from './pages/ViewCustomer'

function PrivateRoute({ children }) {
  const isAuthenticated = useSelector((state) => state.auth.isAuthenticated)
  return isAuthenticated ? children : <Navigate to="/login" replace />
}

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/dashboard"
        element={
          <PrivateRoute>
            <Dashboard />
          </PrivateRoute>
        }
      />
      <Route
        path="/customer-info"
        element={
          <PrivateRoute>
            <CustomerInfo />
          </PrivateRoute>
        }
      />
      <Route
        path="/add-customer"
        element={
          <PrivateRoute>
            <AddCustomer />
          </PrivateRoute>
        }
      />
      <Route
        path="/customer/:id"
        element={
          <PrivateRoute>
            <ViewCustomer />
          </PrivateRoute>
        }
      />
      <Route path="/" element={<Navigate to="/login" replace />} />
    </Routes>
  )
}

export default App
