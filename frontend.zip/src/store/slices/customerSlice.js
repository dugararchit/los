import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api'

// Configure axios to include token in requests
axios.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export const searchCustomers = createAsyncThunk(
  'customer/search',
  async ({ searchBy, value }, { rejectWithValue }) => {
    if (!searchBy || !value) {
      return []
    }

    try {
      const response = await axios.get(
        `${API_URL}/customers/search?searchBy=${searchBy}&value=${value}`
      )
      return response.data
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Search failed'
      )
    }
  }
)

export const fetchAllCustomers = createAsyncThunk(
  'customer/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_URL}/customers`)
      return response.data
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch customers'
      )
    }
  }
)

export const fetchCustomerById = createAsyncThunk(
  'customer/fetchById',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axios.get(`${API_URL}/customers/${id}`)
      return response.data
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to fetch customer'
      )
    }
  }
)

export const addCustomer = createAsyncThunk(
  'customer/add',
  async (customerData, { rejectWithValue }) => {
    try {
      const response = await axios.post(
        `${API_URL}/customers`,
        customerData
      )
      return response.data
    } catch (error) {
      return rejectWithValue(
        error.response?.data?.message || 'Failed to add customer'
      )
    }
  }
)

const customerSlice = createSlice({
  name: 'customer',
  initialState: {
    customers: [],
    searchResults: [],
    currentCustomer: null,
    loading: false,
    error: null,
  },
  reducers: {
    clearSearchResults: (state) => {
      state.searchResults = []
    },
    clearError: (state) => {
      state.error = null
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllCustomers.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchAllCustomers.fulfilled, (state, action) => {
        state.loading = false
        state.customers = action.payload
      })
      .addCase(fetchAllCustomers.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
      })
      .addCase(searchCustomers.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(searchCustomers.fulfilled, (state, action) => {
        state.loading = false
        state.searchResults = action.payload
      })
      .addCase(searchCustomers.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
      })
      .addCase(addCustomer.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(addCustomer.fulfilled, (state, action) => {
        state.loading = false
        state.customers.unshift(action.payload) // Add to beginning
      })
      .addCase(addCustomer.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
      })
      .addCase(fetchCustomerById.pending, (state) => {
        state.loading = true
        state.error = null
      })
      .addCase(fetchCustomerById.fulfilled, (state, action) => {
        state.loading = false
        state.currentCustomer = action.payload
      })
      .addCase(fetchCustomerById.rejected, (state, action) => {
        state.loading = false
        state.error = action.payload
      })
  },
})

export const { clearSearchResults, clearError } = customerSlice.actions
export default customerSlice.reducer
