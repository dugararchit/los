import { Box, Typography } from '@mui/material'

function StatusLogo({ size = 'medium' }) {
  const sizes = {
    small: { width: 120, height: 40, fontSize: '1rem' },
    medium: { width: 180, height: 60, fontSize: '1.5rem' },
    large: { width: 240, height: 80, fontSize: '2rem' },
  }

  const currentSize = sizes[size] || sizes.medium

  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1,
      }}
    >
      <Box
        sx={{
          width: currentSize.width,
          height: currentSize.height,
          backgroundColor: '#6a1b9a',
          borderRadius: 2,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          fontWeight: 'bold',
          fontSize: currentSize.fontSize,
        }}
      >
        <Typography
          variant="h4"
          sx={{
            fontWeight: 'bold',
            color: 'white',
            fontSize: currentSize.fontSize,
          }}
        >
          S
        </Typography>
      </Box>
      <Box sx={{ display: 'flex', flexDirection: 'column' }}>
        <Typography
          variant="h6"
          sx={{
            fontWeight: 'bold',
            color: '#6a1b9a',
            lineHeight: 1,
            fontSize: currentSize.fontSize,
          }}
        >
          STATUS
        </Typography>
        <Typography
          variant="caption"
          sx={{
            color: '#6a1b9a',
            fontSize: currentSize.fontSize * 0.4,
            lineHeight: 1,
          }}
        >
          THE NEW WAY
        </Typography>
      </Box>
    </Box>
  )
}

export default StatusLogo
