import { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import {
  Box,
  Drawer,
  AppBar,
  Toolbar,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  IconButton,
  Avatar,
  Badge,
  useTheme,
  useMediaQuery,
} from '@mui/material'
import {
  Menu as MenuIcon,
  Dashboard as DashboardIcon,
  HourglassEmpty as HourglassIcon,
  Description as DescriptionIcon,
  BarChart as BarChartIcon,
  Settings as SettingsIcon,
  Email as EmailIcon,
  PersonAdd as PersonAddIcon,
  Search as SearchIcon,
  Notifications as NotificationsIcon,
  Apps as AppsIcon,
  Logout as LogoutIcon,
} from '@mui/icons-material'
import { logout } from '../../store/slices/authSlice'
import StatusLogo from '../StatusLogo'

const drawerWidth = 280

const menuItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/dashboard' },
  { text: 'Tat Report List', icon: <HourglassIcon />, path: '/tat-report' },
  { text: 'Lead Report', icon: <DescriptionIcon />, path: '/lead-report' },
  {
    text: 'Application Current Status',
    icon: <BarChartIcon />,
    path: '/application-status',
  },
  {
    text: 'Application Process Status',
    icon: <SettingsIcon />,
    path: '/process-status',
  },
  {
    text: 'Sending & Receiving Report',
    icon: <EmailIcon />,
    path: '/sending-receiving',
  },
  {
    text: 'Search/Add Customer',
    icon: <SearchIcon />,
    path: '/customer-info',
  },
  {
    text: 'Sourced Application List',
    icon: <DescriptionIcon />,
    path: '/sourced-applications',
  },
]

function DashboardLayout({ children }) {
  const theme = useTheme()
  const isMobile = useMediaQuery(theme.breakpoints.down('md'))
  const [mobileOpen, setMobileOpen] = useState(false)
  const [desktopOpen, setDesktopOpen] = useState(true) // Sidebar open by default on desktop
  const navigate = useNavigate()
  const location = useLocation()
  const dispatch = useDispatch()
  const { user } = useSelector((state) => state.auth)

  const handleDrawerToggle = () => {
    if (isMobile) {
      setMobileOpen(!mobileOpen)
    } else {
      setDesktopOpen(!desktopOpen)
    }
  }

  const handleLogout = () => {
    dispatch(logout())
    navigate('/login')
  }

  const drawer = (
    <Box sx={{ 
      height: '100%', 
      backgroundColor: '#f5f5f5',
      borderRight: '1px solid #e0e0e0',
    }}>
      <Box sx={{ 
        p: 2, 
        borderBottom: '1px solid #e0e0e0',
        backgroundColor: '#ffffff',
      }}>
        <StatusLogo size="small" />
      </Box>
      <List sx={{ pt: 2 }}>
        {menuItems.map((item) => (
          <ListItem key={item.text} disablePadding>
            <ListItemButton
              selected={location.pathname === item.path}
              onClick={() => {
                navigate(item.path)
                if (isMobile) setMobileOpen(false)
              }}
              sx={{
                mx: 1,
                mb: 0.5,
                borderRadius: 1,
                '&.Mui-selected': {
                  backgroundColor: '#1976d2',
                  color: 'white',
                  '&:hover': {
                    backgroundColor: '#1565c0',
                  },
                  '& .MuiListItemIcon-root': {
                    color: 'white',
                  },
                },
                '&:hover': {
                  backgroundColor: '#e3f2fd',
                },
              }}
            >
              <ListItemIcon
                sx={{
                  color: location.pathname === item.path ? 'white' : '#424242',
                }}
              >
                {item.icon}
              </ListItemIcon>
              <ListItemText
                primary={item.text}
                primaryTypographyProps={{
                  fontSize: '0.9rem',
                  fontWeight: location.pathname === item.path ? 600 : 400,
                }}
              />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
    </Box>
  )

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      <AppBar
        position="fixed"
        sx={{
          width: { 
            xs: '100%',
            md: desktopOpen ? `calc(100% - ${drawerWidth}px)` : '100%'
          },
          ml: { 
            xs: 0,
            md: desktopOpen ? `${drawerWidth}px` : 0
          },
          transition: theme.transitions.create(['width', 'margin'], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
          }),
          backgroundColor: '#1976d2',
          zIndex: theme.zIndex.drawer + 1,
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="toggle drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center' }}>
            <StatusLogo size="small" />
            <Typography
              variant="h6"
              sx={{
                ml: 2,
                fontWeight: 'bold',
                display: { xs: 'none', sm: 'block' },
              }}
            >
              STATUS LEASING AND FINANCE LTD.
            </Typography>
          </Box>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
            <Badge badgeContent={0} color="error">
              <IconButton color="inherit">
                <NotificationsIcon />
              </IconButton>
            </Badge>
            <IconButton color="inherit">
              <AppsIcon />
            </IconButton>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, ml: 2 }}>
              <Avatar sx={{ width: 32, height: 32, bgcolor: '#42a5f5' }}>
                {user?.name?.charAt(0) || 'U'}
              </Avatar>
              <Typography variant="body2" sx={{ display: { xs: 'none', md: 'block' } }}>
                {user?.name || 'TEST USER'}
              </Typography>
            </Box>
            <IconButton color="inherit" onClick={handleLogout}>
              <LogoutIcon />
            </IconButton>
          </Box>
        </Toolbar>
        <Box
          sx={{
            backgroundColor: '#1565c0',
            height: 48,
            display: 'flex',
            alignItems: 'center',
            px: 2,
          }}
        >
          <IconButton 
            color="inherit" 
            sx={{ mr: 2 }}
            onClick={handleDrawerToggle}
          >
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ color: 'white', fontWeight: 500 }}>
            {menuItems.find((item) => item.path === location.pathname)?.text ||
              'Dashboard'}
          </Typography>
        </Box>
      </AppBar>

      <Box
        component="nav"
        sx={{ width: { md: drawerWidth }, flexShrink: { md: 0 } }}
      >
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true,
          }}
          sx={{
            display: { xs: 'block', md: 'none' },
            '& .MuiDrawer-paper': {
              boxSizing: 'border-box',
              width: drawerWidth,
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="persistent"
          open={desktopOpen}
          sx={{
            display: { xs: 'none', md: 'block' },
            '& .MuiDrawer-paper': {
              boxSizing: 'border-box',
              width: drawerWidth,
              transition: theme.transitions.create('width', {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
              }),
            },
          }}
        >
          {drawer}
        </Drawer>
      </Box>

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { 
            xs: '100%',
            md: desktopOpen ? `calc(100% - ${drawerWidth}px)` : '100%'
          },
          mt: { xs: '112px', md: '112px' },
          backgroundColor: '#f5f5f5',
          minHeight: 'calc(100vh - 112px)',
          transition: theme.transitions.create('width', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
          }),
        }}
      >
        {children}
      </Box>

      <Box
        component="footer"
        sx={{
          position: 'fixed',
          bottom: 0,
          left: { 
            xs: 0,
            md: desktopOpen ? drawerWidth : 0
          },
          right: 0,
          backgroundColor: '#424242',
          color: 'white',
          padding: 1.5,
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          fontSize: '0.75rem',
          zIndex: theme.zIndex.drawer,
          transition: theme.transitions.create('left', {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen,
          }),
        }}
      >
        <Typography variant="body2" sx={{ color: 'white', ml: 2 }}>
          © 2024 Designed and Powered By{' '}
          <Typography
            component="span"
            sx={{ color: '#42a5f5', fontWeight: 500 }}
          >
            Finnaux Techsolutions Pvt. Ltd.
          </Typography>{' '}
          All Rights Reserved
        </Typography>
        <Box sx={{ display: 'flex', gap: 2, mr: 2 }}>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            Download Utilities
          </Typography>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            RBI Circular
          </Typography>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            Contact Us
          </Typography>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            Support
          </Typography>
        </Box>
      </Box>
    </Box>
  )
}

export default DashboardLayout
