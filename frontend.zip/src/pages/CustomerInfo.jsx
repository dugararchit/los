import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  MenuItem,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
  Chip,
} from '@mui/material'
import {
  Search as SearchIcon,
  PersonAdd as PersonAddIcon,
  FileUpload as FileUploadIcon,
  Refresh as RefreshIcon,
} from '@mui/icons-material'
import DashboardLayout from '../components/Layout/DashboardLayout'
import { searchCustomers, fetchAllCustomers } from '../store/slices/customerSlice'

function CustomerInfo() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { customers, searchResults, loading } = useSelector((state) => state.customer)
  const [showAllCustomers, setShowAllCustomers] = useState(true)

  const [searchBy, setSearchBy] = useState('')
  const [searchValue, setSearchValue] = useState('')

  const searchOptions = [
    { value: 'primaryContactNo', label: 'Phone Number' },
    { value: 'firstName', label: 'First Name' },
    { value: 'email', label: 'Email' },
    { value: 'caseNumber', label: 'Case Number' },
  ]

  useEffect(() => {
    dispatch(fetchAllCustomers())
  }, [dispatch])

  const handleSearch = () => {
    if (searchBy && searchValue) {
      setShowAllCustomers(false)
      dispatch(searchCustomers({ searchBy, value: searchValue }))
    }
  }

  const handleShowAll = () => {
    setShowAllCustomers(true)
    dispatch(fetchAllCustomers())
  }

  const displayCustomers = showAllCustomers ? customers : searchResults

  const getStatusColor = (status) => {
    const colors = {
      initialized: 'default',
      manager_approval: 'warning',
      president_approval: 'info',
      final_approval_done: 'success',
      rejected: 'error',
      cancelled: 'default',
    }
    return colors[status] || 'default'
  }

  return (
    <DashboardLayout>
      <Card sx={{ mb: 3, backgroundColor: '#e3f2fd' }}>
        <CardContent>
          <Box
            sx={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: 2,
              alignItems: 'flex-end',
            }}
          >
            <TextField
              select
              label="Search By"
              value={searchBy}
              onChange={(e) => setSearchBy(e.target.value)}
              sx={{ minWidth: 200 }}
              SelectProps={{
                displayEmpty: true,
              }}
            >
              <MenuItem value="">
                <em>Select</em>
              </MenuItem>
              {searchOptions.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </TextField>

            <TextField
              label="Value"
              placeholder="VALUE"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter') handleSearch()
              }}
              sx={{ flexGrow: 1, minWidth: 200 }}
            />

            <Button
              variant="contained"
              startIcon={<SearchIcon />}
              onClick={handleSearch}
              disabled={!searchBy || !searchValue || loading}
            >
              Search
            </Button>

            <Button
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={handleShowAll}
              disabled={loading}
            >
              Show All
            </Button>

            <Button
              variant="contained"
              color="success"
              startIcon={<PersonAddIcon />}
              onClick={() => navigate('/add-customer')}
            >
              Add New Customer
            </Button>

            <Button
              variant="contained"
              color="info"
              startIcon={<FileUploadIcon />}
            >
              Import Customer
            </Button>
          </Box>
        </CardContent>
      </Card>

      <Card>
        <CardContent>
          {loading ? (
            <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
              <CircularProgress />
            </Box>
          ) : displayCustomers.length > 0 ? (
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: '#e3f2fd' }}>
                    <TableCell sx={{ fontWeight: 600 }}>Case Number</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Phone</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Email</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Status</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Created By</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Created At</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {displayCustomers.map((customer) => (
                    <TableRow key={customer.id} hover>
                      <TableCell>
                        <Typography variant="body2" sx={{ fontWeight: 500 }}>
                          {customer.case?.case_number || 'N/A'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        {customer.first_name} {customer.last_name || ''}
                      </TableCell>
                      <TableCell>{customer.primary_contact_no}</TableCell>
                      <TableCell>{customer.email || 'N/A'}</TableCell>
                      <TableCell>
                        <Chip
                          label={customer.case?.status || 'N/A'}
                          color={getStatusColor(customer.case?.status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        <Typography variant="body2" sx={{ color: 'primary.main' }}>
                          {customer.case?.created_by_user?.username || 'admin1'}
                        </Typography>
                      </TableCell>
                      <TableCell>
                        {customer.case?.created_at
                          ? new Date(customer.case.created_at).toLocaleDateString()
                          : 'N/A'}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="small"
                          variant="outlined"
                          onClick={() => navigate(`/customer/${customer.id}`)}
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Box
              sx={{
                minHeight: 400,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: 'white',
              }}
            >
              <Typography variant="h6" color="textSecondary">
                {searchBy && searchValue
                  ? 'No results found'
                  : 'No customers found. Add a new customer to get started.'}
              </Typography>
            </Box>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  )
}

export default CustomerInfo
