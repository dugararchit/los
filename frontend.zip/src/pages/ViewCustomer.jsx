import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useParams, useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  Paper,
  Divider,
  Chip,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material'
import {
  ArrowBack as ArrowBackIcon,
  Person as PersonIcon,
  Phone as PhoneIcon,
  Email as EmailIcon,
  Home as HomeIcon,
  AccountBalance as BankIcon,
  Description as DocumentIcon,
} from '@mui/icons-material'
import DashboardLayout from '../components/Layout/DashboardLayout'
import { fetchCustomerById } from '../store/slices/customerSlice'

function ViewCustomer() {
  const { id } = useParams()
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const { currentCustomer, loading, error } = useSelector((state) => state.customer)

  useEffect(() => {
    if (id) {
      dispatch(fetchCustomerById(id))
    }
  }, [id, dispatch])

  const getStatusColor = (status) => {
    const colors = {
      initialized: 'default',
      manager_approval: 'warning',
      president_approval: 'info',
      final_approval_done: 'success',
      rejected: 'error',
      cancelled: 'default',
    }
    return colors[status] || 'default'
  }

  const getVerificationColor = (status) => {
    const colors = {
      pending: 'warning',
      verified: 'success',
      rejected: 'error',
    }
    return colors[status] || 'default'
  }

  if (loading) {
    return (
      <DashboardLayout>
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}>
          <CircularProgress />
        </Box>
      </DashboardLayout>
    )
  }

  if (error || !currentCustomer) {
    return (
      <DashboardLayout>
        <Card>
          <CardContent>
            <Typography variant="h6" color="error">
              {error || 'Customer not found'}
            </Typography>
            <Button
              startIcon={<ArrowBackIcon />}
              onClick={() => navigate('/customer-info')}
              sx={{ mt: 2 }}
            >
              Back to Customer List
            </Button>
          </CardContent>
        </Card>
      </DashboardLayout>
    )
  }

  const customer = currentCustomer
  const caseInfo = customer.case

  return (
    <DashboardLayout>
      <Box sx={{ mb: 3 }}>
        <Button
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate('/customer-info')}
          sx={{ mb: 2 }}
        >
          Back to Customer List
        </Button>
      </Box>

      {/* Case Information */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a237e' }}>
              Case Information
            </Typography>
            <Chip
              label={caseInfo?.status || 'N/A'}
              color={getStatusColor(caseInfo?.status)}
              sx={{ fontWeight: 600 }}
            />
          </Box>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="textSecondary">
                Case Number
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {caseInfo?.case_number || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="textSecondary">
                Created By
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {caseInfo?.created_by_user?.username || 'admin1'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="textSecondary">
                Priority
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {caseInfo?.priority || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="textSecondary">
                Created At
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {caseInfo?.created_at
                  ? new Date(caseInfo.created_at).toLocaleString()
                  : 'N/A'}
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Customer Personal Information */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a237e', mb: 3 }}>
            <PersonIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
            Personal Information
          </Typography>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="textSecondary">
                Full Name
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.first_name} {customer.last_name || ''}
              </Typography>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="body2" color="textSecondary">
                Type
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.type}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                <PhoneIcon sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5 }} />
                Primary Contact
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.primary_contact_no}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Alternate Contact
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.alternate_no || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                <EmailIcon sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5 }} />
                Email
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.email || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Gender
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.gender}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Date of Birth
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.date_of_birth
                  ? new Date(customer.date_of_birth).toLocaleDateString()
                  : 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Age
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.age || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Marital Status
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.marital_status}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Religion
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.customer_religion || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Caste
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.customer_caste || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Profile
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.customer_profile || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Category
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.customer_category || 'N/A'}
              </Typography>
            </Grid>
            <Grid item xs={12} md={4}>
              <Typography variant="body2" color="textSecondary">
                Nature of Work
              </Typography>
              <Typography variant="body1" sx={{ fontWeight: 500 }}>
                {customer.nature_of_work || 'N/A'}
              </Typography>
            </Grid>
          </Grid>
        </CardContent>
      </Card>

      {/* Addresses */}
      {customer.addresses && customer.addresses.length > 0 && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a237e', mb: 3 }}>
              <HomeIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
              Addresses
            </Typography>
            <Grid container spacing={3}>
              {customer.addresses.map((address, index) => (
                <Grid item xs={12} md={6} key={index}>
                  <Paper sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                      {address.address_type.charAt(0).toUpperCase() + address.address_type.slice(1)} Address
                      {address.is_communication_address && (
                        <Chip label="Communication" size="small" color="primary" sx={{ ml: 1 }} />
                      )}
                    </Typography>
                    <Typography variant="body2">{address.address_line}</Typography>
                    <Typography variant="body2">
                      {address.landmark && `Landmark: ${address.landmark}`}
                    </Typography>
                    <Typography variant="body2">
                      {address.district}, {address.state} - {address.pincode}
                    </Typography>
                    <Typography variant="body2">Tehsil: {address.tehsil}</Typography>
                    {address.no_of_years && (
                      <Typography variant="body2">
                        Years: {address.no_of_years} | {address.rent_own}
                      </Typography>
                    )}
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>
      )}

      {/* KYC Documents */}
      {customer.kyc_documents && customer.kyc_documents.length > 0 && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a237e', mb: 3 }}>
              <DocumentIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
              KYC Documents
            </Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: '#e3f2fd' }}>
                    <TableCell sx={{ fontWeight: 600 }}>Document Type</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Document Number</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Verification Status</TableCell>
                    <TableCell sx={{ fontWeight: 600 }}>Verified By</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {customer.kyc_documents.map((doc, index) => (
                    <TableRow key={index}>
                      <TableCell>{doc.document_type}</TableCell>
                      <TableCell>{doc.document_number}</TableCell>
                      <TableCell>
                        <Chip
                          label={doc.verification_status}
                          color={getVerificationColor(doc.verification_status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        {doc.verified_by_user?.username || 'N/A'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      )}

      {/* Bank Details */}
      {customer.bank_details && customer.bank_details.length > 0 && (
        <Card sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a237e', mb: 3 }}>
              <BankIcon sx={{ verticalAlign: 'middle', mr: 1 }} />
              Bank Details
            </Typography>
            <Grid container spacing={3}>
              {customer.bank_details.map((bank, index) => (
                <Grid item xs={12} md={6} key={index}>
                  <Paper sx={{ p: 2, backgroundColor: '#f5f5f5' }}>
                    {bank.is_primary && (
                      <Chip label="Primary" color="primary" size="small" sx={{ mb: 1 }} />
                    )}
                    <Typography variant="subtitle1" sx={{ fontWeight: 600, mb: 1 }}>
                      {bank.bank_name}
                    </Typography>
                    <Typography variant="body2">
                      <strong>Beneficiary:</strong> {bank.beneficiary}
                    </Typography>
                    <Typography variant="body2">
                      <strong>Account Number:</strong> {bank.account_number}
                    </Typography>
                    <Typography variant="body2">
                      <strong>Branch:</strong> {bank.bank_branch}
                    </Typography>
                    <Typography variant="body2">
                      <strong>Account Type:</strong> {bank.account_type}
                    </Typography>
                    <Typography variant="body2">
                      <strong>IFSC:</strong> {bank.ifsc_code}
                    </Typography>
                    {bank.micr_code && (
                      <Typography variant="body2">
                        <strong>MICR:</strong> {bank.micr_code}
                      </Typography>
                    )}
                    <Box sx={{ mt: 1 }}>
                      <Chip
                        label={bank.verification_status}
                        color={getVerificationColor(bank.verification_status)}
                        size="small"
                      />
                    </Box>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </CardContent>
        </Card>
      )}
    </DashboardLayout>
  )
}

export default ViewCustomer
