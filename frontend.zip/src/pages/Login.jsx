import { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  TextField,
  Button,
  Typography,
  InputAdornment,
  IconButton,
  Alert,
} from '@mui/material'
import {
  Person as PersonIcon,
  Lock as LockIcon,
  Visibility,
  VisibilityOff,
} from '@mui/icons-material'
import { login, clearError } from '../store/slices/authSlice'
import StatusLogo from '../components/StatusLogo'

function Login() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const { loading, error } = useSelector((state) => state.auth)

  const [formData, setFormData] = useState({
    userId: '',
    password: '',
  })
  const [errors, setErrors] = useState({})
  const [showPassword, setShowPassword] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }))
    }
    if (error) {
      dispatch(clearError())
    }
  }

  const validate = () => {
    const newErrors = {}
    if (!formData.userId.trim()) {
      newErrors.userId = 'User ID is required'
    }
    if (!formData.password) {
      newErrors.password = 'Password is required'
    }
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!validate()) return

    try {
      const result = await dispatch(login(formData)).unwrap()
      if (result) {
        navigate('/dashboard')
      }
    } catch (err) {
      // Error handled by Redux
    }
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        backgroundColor: '#e3f2fd',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 2,
      }}
    >
      <Card
        sx={{
          width: '100%',
          maxWidth: 450,
          padding: 4,
          borderRadius: 2,
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'center', mb: 4 }}>
          <StatusLogo />
        </Box>

        <Box component="form" onSubmit={handleSubmit}>
          <TextField
            fullWidth
            name="userId"
            label="User ID"
            placeholder="Enter User ID"
            value={formData.userId}
            onChange={handleChange}
            error={!!errors.userId}
            helperText={errors.userId}
            sx={{ 
              mb: 2.5,
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: errors.userId ? '#ef4444' : 'rgba(0, 0, 0, 0.1)',
                },
              },
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <PersonIcon sx={{ color: '#1976d2' }} />
                </InputAdornment>
              ),
            }}
          />

          {errors.userId && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {errors.userId}
            </Alert>
          )}

          <TextField
            fullWidth
            name="password"
            label="Password"
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={formData.password}
            onChange={handleChange}
            error={!!errors.password}
            helperText={errors.password}
            sx={{ 
              mb: 2.5,
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: errors.password ? '#ef4444' : 'rgba(0, 0, 0, 0.1)',
                },
              },
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <LockIcon sx={{ color: '#2e7d32' }} />
                </InputAdornment>
              ),
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton
                    onClick={() => setShowPassword(!showPassword)}
                    edge="end"
                    sx={{
                      color: '#757575',
                      '&:hover': {
                        backgroundColor: 'rgba(0, 0, 0, 0.04)',
                      },
                    }}
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 3 }}>
            <Typography
              component="a"
              href="#"
              sx={{
                color: 'primary.main',
                textDecoration: 'none',
                fontSize: '0.875rem',
                '&:hover': {
                  textDecoration: 'underline',
                },
              }}
            >
              Forgot Password?
            </Typography>
          </Box>

          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          <Button
            type="submit"
            fullWidth
            variant="contained"
            disabled={loading}
            sx={{
              padding: '12px',
              fontSize: '1rem',
              fontWeight: 600,
              textTransform: 'uppercase',
            }}
          >
            {loading ? 'Submitting...' : 'Submit'}
          </Button>
        </Box>
      </Card>

      <Box
        sx={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: '#424242',
          color: 'white',
          padding: 2,
          textAlign: 'center',
          fontSize: '0.875rem',
        }}
      >
        <Typography variant="body2" sx={{ color: 'white' }}>
          © 2024 Designed and Powered By{' '}
          <Typography
            component="span"
            sx={{ color: '#42a5f5', fontWeight: 500 }}
          >
            Firraux Techsolutions Pvt. Ltd.
          </Typography>{' '}
          All Rights Reserved
        </Typography>
        <Box sx={{ mt: 1, display: 'flex', justifyContent: 'center', gap: 2 }}>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            RBI Circular
          </Typography>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            Contact Us
          </Typography>
          <Typography
            component="a"
            href="#"
            sx={{ color: '#42a5f5', textDecoration: 'none' }}
          >
            Support
          </Typography>
        </Box>
      </Box>
    </Box>
  )
}

export default Login
