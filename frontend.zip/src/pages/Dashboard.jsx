import { Box, Typography, Card, CardContent } from '@mui/material'
import DashboardLayout from '../components/Layout/DashboardLayout'
import StatusLogo from '../components/StatusLogo'

function Dashboard() {
  return (
    <DashboardLayout>
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          minHeight: '60vh',
        }}
      >
        <Card
          sx={{
            p: 4,
            textAlign: 'center',
            backgroundColor: 'white',
            boxShadow: 3,
          }}
        >
          <Box sx={{ mb: 3 }}>
            <StatusLogo size="large" />
          </Box>
          <Typography
            variant="h5"
            sx={{
              color: '#0288d1',
              fontWeight: 600,
              mb: 1,
            }}
          >
            POWERED BY FINNAUX TECHSOLUTIONS
          </Typography>
          <Typography
            variant="h6"
            sx={{
              color: '#0288d1',
              fontWeight: 500,
            }}
          >
            LIMITED
          </Typography>
        </Card>
      </Box>
    </DashboardLayout>
  )
}

export default Dashboard
