import { useState } from 'react'
import { useFormik } from 'formik'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import {
  Box,
  Card,
  CardContent,
  TextField,
  Button,
  Typography,
  MenuItem,
  Grid,
  Checkbox,
  FormControlLabel,
  IconButton,
  Divider,
  Paper,
} from '@mui/material'
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  CloudUpload as CloudUploadIcon,
  Cancel as CancelIcon,
} from '@mui/icons-material'
import DashboardLayout from '../components/Layout/DashboardLayout'
import { addCustomer } from '../store/slices/customerSlice'
import * as Yup from 'yup'

const validationSchema = Yup.object({
  type: Yup.string().required('Type is required'),
  firstName: Yup.string().required('First Name is required'),
  relation: Yup.string().required('Relation is required'),
  gender: Yup.string().required('Gender is required'),
  dob: Yup.string().required('Date of Birth is required'),
  primaryContactNo: Yup.string().required('Primary Contact No. is required'),
  maritalStatus: Yup.string().required('Marital Status is required'),
  customerReligion: Yup.string().required('Customer Religion is required'),
  customerProfile: Yup.string().required('Customer Profile is required'),
  customerCategory: Yup.string().required('Customer Category is required'),
  subCategory: Yup.string().required('Sub-Category is required'),
  natureOfWork: Yup.string().required('Nature of work is required'),
  customerCaste: Yup.string().required('Customer Caste is required'),
  businessType: Yup.string().required('Type is required'),
  presentAddress: Yup.string().required('Present Address is required'),
  presentLandmark: Yup.string().required('Present Landmark is required'),
  presentPinCode: Yup.string().required('Present PinCode is required'),
  presentState: Yup.string().required('Present State is required'),
  presentDistrict: Yup.string().required('Present District is required'),
  presentTehsil: Yup.string().required('Present Tehsil is required'),
  presentNoOfYears: Yup.string().required('No of Year Living Here is required'),
  presentRentOwn: Yup.string().required('Rent/Own is required'),
  presentDistance: Yup.string().required('Distance To Branch is required'),
})

function AddCustomer() {
  const dispatch = useDispatch()
  const navigate = useNavigate()
  const [kycDocuments, setKycDocuments] = useState([
    {
      documentType: '',
      documentNumber: '',
      documentImage: null,
      documentImage1: null,
    },
  ])
  const [bankDetails, setBankDetails] = useState([
    {
      beneficiary: '',
      accountNo: '',
      bankName: '',
      bankBranch: '',
      accountType: '',
      ifscCode: '',
      micrCode: '',
    },
  ])

  const formik = useFormik({
    initialValues: {
      type: 'Individual',
      // KYC Documents
      // Demographic Information
      firstName: '',
      lastName: '',
      relation: '',
      relationFirstName: '',
      relationLastName: '',
      customerPhoto: null,
      gender: '',
      dob: '',
      age: '',
      primaryContactNo: '',
      email: '',
      otherEmailId: '',
      whatsAppNo: '',
      maritalStatus: '',
      customerReligion: '',
      alternateNo: '',
      customerProfile: '',
      customerCategory: '',
      subCategory: '',
      natureOfWork: '',
      customerCaste: '',
      businessType: '',
      // Present Address
      presentAddress: '',
      presentLandmark: '',
      presentPinCode: '',
      presentState: '',
      presentDistrict: '',
      presentTehsil: '',
      presentNoOfYears: '',
      presentRentOwn: '',
      presentDistance: '',
      presentIsCommunication: false,
      // Permanent Address
      permanentSameAsPresent: false,
      permanentAddress: '',
      permanentLandmark: '',
      permanentPinCode: '',
      permanentState: '',
      permanentDistrict: '',
      permanentTehsil: '',
      permanentNoOfYears: '',
      permanentRentOwn: '',
      permanentDistance: '',
      permanentIsCommunication: false,
      // Work Address
      workAddress: '',
      workLandmark: '',
      workPinCode: '',
      workState: '',
      workDistrict: '',
      workTehsil: '',
      workNoOfYears: '',
      workRentOwn: '',
      workDistance: '',
      workIsCommunication: false,
    },
    validationSchema,
    onSubmit: async (values) => {
      const customerData = {
        ...values,
        kycDocuments,
        bankDetails,
      }
      try {
        await dispatch(addCustomer(customerData)).unwrap()
        navigate('/customer-info')
      } catch (error) {
        console.error('Error adding customer:', error)
      }
    },
  })

  const addKycDocument = () => {
    setKycDocuments([
      ...kycDocuments,
      {
        documentType: '',
        documentNumber: '',
        documentImage: null,
        documentImage1: null,
      },
    ])
  }

  const removeKycDocument = (index) => {
    setKycDocuments(kycDocuments.filter((_, i) => i !== index))
  }

  const updateKycDocument = (index, field, value) => {
    const updated = [...kycDocuments]
    updated[index][field] = value
    setKycDocuments(updated)
  }

  const addBankDetail = () => {
    setBankDetails([
      ...bankDetails,
      {
        beneficiary: '',
        accountNo: '',
        bankName: '',
        bankBranch: '',
        accountType: '',
        ifscCode: '',
        micrCode: '',
      },
    ])
  }

  const removeBankDetail = (index) => {
    setBankDetails(bankDetails.filter((_, i) => i !== index))
  }

  const updateBankDetail = (index, field, value) => {
    const updated = [...bankDetails]
    updated[index][field] = value
    setBankDetails(updated)
  }

  const handlePermanentSameAsPresent = (checked) => {
    if (checked) {
      formik.setValues({
        ...formik.values,
        permanentSameAsPresent: true,
        permanentAddress: formik.values.presentAddress,
        permanentLandmark: formik.values.presentLandmark,
        permanentPinCode: formik.values.presentPinCode,
        permanentState: formik.values.presentState,
        permanentDistrict: formik.values.presentDistrict,
        permanentTehsil: formik.values.presentTehsil,
        permanentNoOfYears: formik.values.presentNoOfYears,
        permanentRentOwn: formik.values.presentRentOwn,
        permanentDistance: formik.values.presentDistance,
      })
    } else {
      formik.setFieldValue('permanentSameAsPresent', false)
    }
  }

  // Dropdown options with improved labels
  const typeOptions = [
    { value: 'Individual', label: 'Individual' },
    { value: 'Corporate', label: 'Corporate' },
    { value: 'Partnership', label: 'Partnership' },
    { value: 'Other', label: 'Other' },
  ]
  const relationOptions = [
    { value: 'self', label: 'Self' },
    { value: 'father', label: 'Father' },
    { value: 'mother', label: 'Mother' },
    { value: 'spouse', label: 'Spouse' },
    { value: 'son', label: 'Son' },
    { value: 'daughter', label: 'Daughter' },
    { value: 'other', label: 'Other' },
  ]
  const genderOptions = [
    { value: 'Male', label: 'Male' },
    { value: 'Female', label: 'Female' },
    { value: 'Other', label: 'Other' },
  ]
  const maritalStatusOptions = [
    { value: 'Single', label: 'Single' },
    { value: 'Married', label: 'Married' },
    { value: 'Divorced', label: 'Divorced' },
    { value: 'Widowed', label: 'Widowed' },
    { value: 'Separated', label: 'Separated' },
  ]
  const religionOptions = [
    { value: 'Hindu', label: 'Hindu' },
    { value: 'Muslim', label: 'Muslim' },
    { value: 'Christian', label: 'Christian' },
    { value: 'Sikh', label: 'Sikh' },
    { value: 'Buddhist', label: 'Buddhist' },
    { value: 'Jain', label: 'Jain' },
    { value: 'Other', label: 'Other' },
  ]
  const customerProfileOptions = [
    { value: 'Salaried', label: 'Salaried Employee' },
    { value: 'Business', label: 'Business Owner' },
    { value: 'Professional', label: 'Professional (Doctor/Lawyer/CA)' },
    { value: 'Self-Employed', label: 'Self-Employed' },
    { value: 'Retired', label: 'Retired' },
    { value: 'Student', label: 'Student' },
    { value: 'Housewife', label: 'Housewife' },
    { value: 'Other', label: 'Other' },
  ]
  const customerCategoryOptions = [
    { value: 'Retail', label: 'Retail Customer' },
    { value: 'Corporate', label: 'Corporate Customer' },
    { value: 'SME', label: 'Small & Medium Enterprise (SME)' },
    { value: 'Priority', label: 'Priority Banking' },
    { value: 'Rural', label: 'Rural Customer' },
    { value: 'Other', label: 'Other' },
  ]
  const subCategoryOptions = [
    { value: 'Government Employee', label: 'Government Employee' },
    { value: 'Private Employee', label: 'Private Employee' },
    { value: 'Small Business', label: 'Small Business (< 10 Cr)' },
    { value: 'Medium Business', label: 'Medium Business (10-50 Cr)' },
    { value: 'Large Business', label: 'Large Business (> 50 Cr)' },
    { value: 'Professional Services', label: 'Professional Services' },
    { value: 'Trading', label: 'Trading' },
    { value: 'Manufacturing', label: 'Manufacturing' },
    { value: 'Other', label: 'Other' },
  ]
  const natureOfWorkOptions = [
    { value: 'Salaried', label: 'Salaried' },
    { value: 'Business', label: 'Business' },
    { value: 'Self-Employed', label: 'Self-Employed' },
    { value: 'Professional', label: 'Professional' },
    { value: 'Agriculture', label: 'Agriculture' },
    { value: 'Service', label: 'Service Industry' },
    { value: 'Trading', label: 'Trading' },
    { value: 'Other', label: 'Other' },
  ]
  const casteOptions = [
    { value: 'General', label: 'General' },
    { value: 'OBC', label: 'Other Backward Class (OBC)' },
    { value: 'SC', label: 'Scheduled Caste (SC)' },
    { value: 'ST', label: 'Scheduled Tribe (ST)' },
    { value: 'Other', label: 'Other' },
  ]
  const businessTypeOptions = [
    { value: 'Sole Proprietorship', label: 'Sole Proprietorship' },
    { value: 'Partnership', label: 'Partnership' },
    { value: 'Private Limited', label: 'Private Limited Company' },
    { value: 'Public Limited', label: 'Public Limited Company' },
    { value: 'LLP', label: 'Limited Liability Partnership (LLP)' },
    { value: 'HUF', label: 'Hindu Undivided Family (HUF)' },
    { value: 'Other', label: 'Other' },
  ]
  const stateOptions = [
    { value: 'Karnataka', label: 'Karnataka' },
    { value: 'Maharashtra', label: 'Maharashtra' },
    { value: 'Tamil Nadu', label: 'Tamil Nadu' },
    { value: 'Delhi', label: 'Delhi' },
    { value: 'Gujarat', label: 'Gujarat' },
    { value: 'Rajasthan', label: 'Rajasthan' },
    { value: 'Uttar Pradesh', label: 'Uttar Pradesh' },
    { value: 'West Bengal', label: 'West Bengal' },
    { value: 'Telangana', label: 'Telangana' },
    { value: 'Andhra Pradesh', label: 'Andhra Pradesh' },
    { value: 'Kerala', label: 'Kerala' },
    { value: 'Punjab', label: 'Punjab' },
    { value: 'Haryana', label: 'Haryana' },
    { value: 'Madhya Pradesh', label: 'Madhya Pradesh' },
    { value: 'Other', label: 'Other' },
  ]
  const districtOptions = [
    { value: 'Bangalore', label: 'Bangalore' },
    { value: 'Mumbai', label: 'Mumbai' },
    { value: 'Chennai', label: 'Chennai' },
    { value: 'Hyderabad', label: 'Hyderabad' },
    { value: 'Pune', label: 'Pune' },
    { value: 'Delhi', label: 'Delhi' },
    { value: 'Kolkata', label: 'Kolkata' },
    { value: 'Ahmedabad', label: 'Ahmedabad' },
    { value: 'Jaipur', label: 'Jaipur' },
    { value: 'Other', label: 'Other' },
  ]
  const tehsilOptions = [
    { value: 'Bangalore North', label: 'Bangalore North' },
    { value: 'Bangalore South', label: 'Bangalore South' },
    { value: 'Bangalore Central', label: 'Bangalore Central' },
    { value: 'Bangalore East', label: 'Bangalore East' },
    { value: 'Bangalore West', label: 'Bangalore West' },
    { value: 'Other', label: 'Other' },
  ]
  const rentOwnOptions = [
    { value: 'Rent', label: 'Rent' },
    { value: 'Own', label: 'Own' },
    { value: 'Lease', label: 'Lease' },
    { value: 'Family Property', label: 'Family Property' },
  ]
  const accountTypeOptions = [
    { value: 'Savings', label: 'Savings Account' },
    { value: 'Current', label: 'Current Account' },
    { value: 'Salary', label: 'Salary Account' },
    { value: 'Fixed Deposit', label: 'Fixed Deposit' },
    { value: 'Recurring Deposit', label: 'Recurring Deposit' },
    { value: 'NRI Account', label: 'NRI Account' },
    { value: 'Other', label: 'Other' },
  ]
  const documentTypeOptions = [
    { value: 'Aadhaar', label: 'Aadhaar Card' },
    { value: 'PAN', label: 'PAN Card' },
    { value: 'Passport', label: 'Passport' },
    { value: 'Driving License', label: 'Driving License' },
    { value: 'Voter ID', label: 'Voter ID Card' },
    { value: 'Ration Card', label: 'Ration Card' },
    { value: 'Bank Statement', label: 'Bank Statement' },
    { value: 'Other', label: 'Other' },
  ]

  return (
    <DashboardLayout>
      <Paper
        sx={{
          p: 3,
          backgroundColor: 'white',
          maxHeight: 'calc(100vh - 200px)',
          overflowY: 'auto',
        }}
      >
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            mb: 3,
            pb: 2,
            borderBottom: '2px solid #1a237e',
          }}
        >
          <Typography variant="h5" sx={{ fontWeight: 600, color: '#1a237e' }}>
            Add Customer
          </Typography>
          <IconButton onClick={() => navigate('/customer-info')}>
            <CancelIcon />
          </IconButton>
        </Box>

        <form onSubmit={formik.handleSubmit}>
          {/* Type Section */}
          <Card sx={{ mb: 4 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 3, color: '#1a237e', fontWeight: 600 }}>
                Type
              </Typography>
              <TextField
                fullWidth
                select
                name="type"
                label="Customer Type*"
                value={formik.values.type}
                onChange={formik.handleChange}
                    error={formik.touched.type && Boolean(formik.errors.type)}
                    helperText={formik.touched.type && formik.errors.type}
                  >
                {typeOptions.map((option) => (
                  <MenuItem key={option.value} value={option.value}>
                    {option.label}
                  </MenuItem>
                ))}
              </TextField>
            </CardContent>
          </Card>

          {/* KYC Documents Section */}
          <Card sx={{ mb: 4 }}>
            <CardContent sx={{ p: 3 }}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  mb: 3,
                }}
              >
                <Typography variant="h6" sx={{ color: '#1a237e', fontWeight: 600 }}>
                  KYC Documents:
                </Typography>
                <Button
                  startIcon={<AddIcon />}
                  onClick={addKycDocument}
                  variant="outlined"
                  size="small"
                >
                  Add Document
                </Button>
              </Box>
              {kycDocuments.map((doc, index) => (
                <Box key={index} sx={{ mb: 4, p: 3, border: '1px solid #e0e0e0', borderRadius: 2, backgroundColor: '#fafafa' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                    <Typography variant="subtitle2">
                      Document {index + 1}
                    </Typography>
                    {kycDocuments.length > 1 && (
                      <IconButton
                        size="small"
                        onClick={() => removeKycDocument(index)}
                        color="error"
                      >
                        <DeleteIcon />
                      </IconButton>
                    )}
                  </Box>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        select
                        label="Document Type*"
                        value={doc.documentType}
                        onChange={(e) =>
                          updateKycDocument(index, 'documentType', e.target.value)
                        }
                        SelectProps={{
                          displayEmpty: true,
                        }}
                      >
                        <MenuItem value="">
                          <em>Select Document type</em>
                        </MenuItem>
                        {documentTypeOptions.map((option) => (
                          <MenuItem key={option.value} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Document Number*"
                        placeholder="DOCUMENT NUMBER"
                        value={doc.documentNumber}
                        onChange={(e) =>
                          updateKycDocument(index, 'documentNumber', e.target.value)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} md={2}>
                      <Button
                        fullWidth
                        variant="outlined"
                        component="label"
                        startIcon={<CloudUploadIcon />}
                        sx={{ py: 1.5, mt: '8px' }}
                      >
                        Upload Image
                        <input
                          type="file"
                          hidden
                          accept="image/*"
                          onChange={(e) =>
                            updateKycDocument(index, 'documentImage', e.target.files[0])
                          }
                        />
                      </Button>
                    </Grid>
                    <Grid item xs={12} md={2}>
                      <Button
                        fullWidth
                        variant="outlined"
                        component="label"
                        startIcon={<CloudUploadIcon />}
                        sx={{ py: 1.5, mt: '8px' }}
                      >
                        Upload Image1
                        <input
                          type="file"
                          hidden
                          accept="image/*"
                          onChange={(e) =>
                            updateKycDocument(index, 'documentImage1', e.target.files[0])
                          }
                        />
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              ))}
            </CardContent>
          </Card>

          {/* Demographic Information Section */}
          <Card sx={{ mb: 4 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 3, color: '#1a237e', fontWeight: 600 }}>
                Demographic Information:
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="firstName"
                    label="First Name*"
                    placeholder="FIRST NAME"
                    value={formik.values.firstName}
                    onChange={formik.handleChange}
                    error={formik.touched.firstName && Boolean(formik.errors.firstName)}
                    helperText={formik.touched.firstName && formik.errors.firstName}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="lastName"
                    label="Last Name"
                    placeholder="LAST NAME"
                    value={formik.values.lastName}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="relation"
                    label="Relation to Applicant*"
                    value={formik.values.relation}
                    onChange={formik.handleChange}
                    error={formik.touched.relation && Boolean(formik.errors.relation)}
                    helperText={formik.touched.relation && formik.errors.relation}
                  >
                    {relationOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="relationFirstName"
                    label="First Name*"
                    placeholder="FIRST NAME"
                    value={formik.values.relationFirstName}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="relationLastName"
                    label="Last Name"
                    placeholder="LAST NAME"
                    value={formik.values.relationLastName}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, pt: 1 }}>
                    <Typography variant="body2" sx={{ minWidth: 'fit-content' }}>Customer Photo:</Typography>
                    <Button
                      variant="outlined"
                      component="label"
                      size="small"
                      startIcon={<CloudUploadIcon />}
                    >
                      Upload Photo
                      <input
                        type="file"
                        hidden
                        accept="image/*"
                        onChange={(e) =>
                          formik.setFieldValue('customerPhoto', e.target.files[0])
                        }
                      />
                    </Button>
                  </Box>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="gender"
                    label="Gender*"
                    value={formik.values.gender}
                    onChange={formik.handleChange}
                    error={formik.touched.gender && Boolean(formik.errors.gender)}
                    helperText={formik.touched.gender && formik.errors.gender}
                  >
                    {genderOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    name="dob"
                    label="DOB*"
                    type="date"
                    placeholder="DD/MM/YYYY"
                    value={formik.values.dob}
                    onChange={formik.handleChange}
                    error={formik.touched.dob && Boolean(formik.errors.dob)}
                    helperText={formik.touched.dob && formik.errors.dob}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    name="age"
                    label="Age"
                    placeholder="AGE"
                    value={formik.values.age}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    name="primaryContactNo"
                    label="Primary Contact No.*"
                    placeholder="PRIMARY NO"
                    value={formik.values.primaryContactNo}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.primaryContactNo &&
                      Boolean(formik.errors.primaryContactNo)
                    }
                    helperText={
                      formik.touched.primaryContactNo && formik.errors.primaryContactNo
                    }
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="email"
                    label="Email"
                    placeholder="EMAIL"
                    type="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="otherEmailId"
                    label="Other Email Id"
                    placeholder="EMAIL"
                    type="email"
                    value={formik.values.otherEmailId}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={4}>
                  <TextField
                    fullWidth
                    name="whatsAppNo"
                    label="WhatsApp No."
                    placeholder="WHATSAPP NO"
                    value={formik.values.whatsAppNo}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="maritalStatus"
                    label="Marital Status*"
                    value={formik.values.maritalStatus}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.maritalStatus &&
                      Boolean(formik.errors.maritalStatus)
                    }
                    helperText={
                      formik.touched.maritalStatus && formik.errors.maritalStatus
                    }
                  >
                    {maritalStatusOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="customerReligion"
                    label="Customer Religion*"
                    value={formik.values.customerReligion}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.customerReligion &&
                      Boolean(formik.errors.customerReligion)
                    }
                    helperText={
                      formik.touched.customerReligion && formik.errors.customerReligion
                    }
                  >
                    {religionOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    name="alternateNo"
                    label="Alternate No."
                    placeholder="ALTERNATE NO."
                    value={formik.values.alternateNo}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="customerProfile"
                    label="Customer Profile*"
                    value={formik.values.customerProfile}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.customerProfile &&
                      Boolean(formik.errors.customerProfile)
                    }
                    helperText={
                      formik.touched.customerProfile && formik.errors.customerProfile
                    }
                  >
                    {customerProfileOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="customerCategory"
                    label="Customer Category*"
                    value={formik.values.customerCategory}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.customerCategory &&
                      Boolean(formik.errors.customerCategory)
                    }
                    helperText={
                      formik.touched.customerCategory && formik.errors.customerCategory
                    }
                  >
                    {customerCategoryOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} sm={6} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="subCategory"
                    label="Sub-Category*"
                    value={formik.values.subCategory}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.subCategory && Boolean(formik.errors.subCategory)
                    }
                    helperText={formik.touched.subCategory && formik.errors.subCategory}
                  >
                    {subCategoryOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="natureOfWork"
                    label="Nature of work*"
                    value={formik.values.natureOfWork}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.natureOfWork &&
                      Boolean(formik.errors.natureOfWork)
                    }
                    helperText={
                      formik.touched.natureOfWork && formik.errors.natureOfWork
                    }
                  >
                    {natureOfWorkOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="customerCaste"
                    label="Customer Caste*"
                    value={formik.values.customerCaste}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.customerCaste &&
                      Boolean(formik.errors.customerCaste)
                    }
                    helperText={
                      formik.touched.customerCaste && formik.errors.customerCaste
                    }
                  >
                    {casteOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={3}>
                  <TextField
                    fullWidth
                    select
                    name="businessType"
                    label="Type*"
                    value={formik.values.businessType}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.businessType &&
                      Boolean(formik.errors.businessType)
                    }
                    helperText={
                      formik.touched.businessType && formik.errors.businessType
                    }
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select Business Type</em>
                    </MenuItem>
                    {businessTypeOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Customer Address Section */}
          <Card sx={{ mb: 4 }}>
            <CardContent sx={{ p: 3 }}>
              <Typography variant="h6" sx={{ mb: 3, color: '#1a237e', fontWeight: 600 }}>
                Customer Address:
              </Typography>

              {/* Present Address */}
              <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
                Present Address
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    name="presentAddress"
                    label="Address*"
                    placeholder="ADDRESS"
                    multiline
                    rows={2}
                    value={formik.values.presentAddress}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentAddress &&
                      Boolean(formik.errors.presentAddress)
                    }
                    helperText={
                      formik.touched.presentAddress && formik.errors.presentAddress
                    }
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="presentLandmark"
                    label="Landmark*"
                    placeholder="LANDMARK"
                    value={formik.values.presentLandmark}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentLandmark &&
                      Boolean(formik.errors.presentLandmark)
                    }
                    helperText={
                      formik.touched.presentLandmark && formik.errors.presentLandmark
                    }
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="presentPinCode"
                    label="PinCode*"
                    placeholder="PINCODE"
                    value={formik.values.presentPinCode}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentPinCode &&
                      Boolean(formik.errors.presentPinCode)
                    }
                    helperText={
                      formik.touched.presentPinCode && formik.errors.presentPinCode
                    }
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="presentState"
                    label="State*"
                    value={formik.values.presentState}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentState &&
                      Boolean(formik.errors.presentState)
                    }
                    helperText={
                      formik.touched.presentState && formik.errors.presentState
                    }
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select State</em>
                    </MenuItem>
                    {stateOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="presentDistrict"
                    label="District*"
                    value={formik.values.presentDistrict}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentDistrict &&
                      Boolean(formik.errors.presentDistrict)
                    }
                    helperText={
                      formik.touched.presentDistrict && formik.errors.presentDistrict
                    }
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select District</em>
                    </MenuItem>
                    {districtOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="presentTehsil"
                    label="Tehsil*"
                    value={formik.values.presentTehsil}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentTehsil &&
                      Boolean(formik.errors.presentTehsil)
                    }
                    helperText={
                      formik.touched.presentTehsil && formik.errors.presentTehsil
                    }
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select Tehsil</em>
                    </MenuItem>
                    {tehsilOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="presentNoOfYears"
                    label="No of Year Living Here*"
                    value={formik.values.presentNoOfYears}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentNoOfYears &&
                      Boolean(formik.errors.presentNoOfYears)
                    }
                    helperText={
                      formik.touched.presentNoOfYears &&
                      formik.errors.presentNoOfYears
                    }
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="presentRentOwn"
                    label="Rent/Own*"
                    value={formik.values.presentRentOwn}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentRentOwn &&
                      Boolean(formik.errors.presentRentOwn)
                    }
                    helperText={
                      formik.touched.presentRentOwn && formik.errors.presentRentOwn
                    }
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select</em>
                    </MenuItem>
                    {rentOwnOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="presentDistance"
                    label="Distance To Branch(KM)*"
                    placeholder="DISTANCE FROM BRANCH"
                    value={formik.values.presentDistance}
                    onChange={formik.handleChange}
                    error={
                      formik.touched.presentDistance &&
                      Boolean(formik.errors.presentDistance)
                    }
                    helperText={
                      formik.touched.presentDistance && formik.errors.presentDistance
                    }
                  />
                </Grid>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.presentIsCommunication}
                        onChange={formik.handleChange}
                        name="presentIsCommunication"
                      />
                    }
                    label="Is This Communication Address"
                  />
                </Grid>
              </Grid>

              <Divider sx={{ my: 3 }} />

              {/* Permanent Address */}
              <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
                Permanent Address
              </Typography>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={formik.values.permanentSameAsPresent}
                    onChange={(e) => handlePermanentSameAsPresent(e.target.checked)}
                  />
                }
                label="Select if Permanent Address same as Present Address"
                sx={{ mb: 3 }}
              />
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    name="permanentAddress"
                    label="Address*"
                    placeholder="ADDRESS"
                    multiline
                    rows={2}
                    value={formik.values.permanentAddress}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="permanentLandmark"
                    label="Landmark*"
                    placeholder="LANDMARK"
                    value={formik.values.permanentLandmark}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="permanentPinCode"
                    label="PinCode*"
                    placeholder="PINCODE"
                    value={formik.values.permanentPinCode}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="permanentState"
                    label="State*"
                    value={formik.values.permanentState}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select State</em>
                    </MenuItem>
                    {stateOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="permanentDistrict"
                    label="District*"
                    value={formik.values.permanentDistrict}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select District</em>
                    </MenuItem>
                    {districtOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="permanentTehsil"
                    label="Tehsil*"
                    value={formik.values.permanentTehsil}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select Tehsil</em>
                    </MenuItem>
                    {tehsilOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="permanentNoOfYears"
                    label="No of Year Living Here*"
                    value={formik.values.permanentNoOfYears}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="permanentRentOwn"
                    label="Rent/Own*"
                    value={formik.values.permanentRentOwn}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select</em>
                    </MenuItem>
                    {rentOwnOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="permanentDistance"
                    label="Distance To Branch(KM)*"
                    placeholder="DISTANCE FROM BRANCH"
                    value={formik.values.permanentDistance}
                    onChange={formik.handleChange}
                    disabled={formik.values.permanentSameAsPresent}
                  />
                </Grid>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.permanentIsCommunication}
                        onChange={formik.handleChange}
                        name="permanentIsCommunication"
                      />
                    }
                    label="Is This Communication Address"
                  />
                </Grid>
              </Grid>

              <Divider sx={{ my: 3 }} />

              {/* Work Address */}
              <Typography variant="subtitle1" sx={{ mb: 2, fontWeight: 600 }}>
                Work Address
              </Typography>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    name="workAddress"
                    label="Address"
                    placeholder="ADDRESS"
                    multiline
                    rows={2}
                    value={formik.values.workAddress}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="workLandmark"
                    label="Landmark"
                    placeholder="LANDMARK"
                    value={formik.values.workLandmark}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="workPinCode"
                    label="PinCode"
                    placeholder="PINCODE"
                    value={formik.values.workPinCode}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="workState"
                    label="State"
                    value={formik.values.workState}
                    onChange={formik.handleChange}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select State</em>
                    </MenuItem>
                    {stateOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="workDistrict"
                    label="District"
                    value={formik.values.workDistrict}
                    onChange={formik.handleChange}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select District</em>
                    </MenuItem>
                    {districtOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="workTehsil"
                    label="Tehsil"
                    value={formik.values.workTehsil}
                    onChange={formik.handleChange}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select Tehsil</em>
                    </MenuItem>
                    {tehsilOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="workNoOfYears"
                    label="No of Year Working Here"
                    value={formik.values.workNoOfYears}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    select
                    name="workRentOwn"
                    label="Rent/Own"
                    value={formik.values.workRentOwn}
                    onChange={formik.handleChange}
                    SelectProps={{
                      displayEmpty: true,
                    }}
                  >
                    <MenuItem value="">
                      <em>Select</em>
                    </MenuItem>
                    {rentOwnOptions.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.label}
                      </MenuItem>
                    ))}
                  </TextField>
                </Grid>
                <Grid item xs={12} md={4}>
                  <TextField
                    fullWidth
                    name="workDistance"
                    label="Distance To Branch(KM)"
                    placeholder="DISTANCE FROM BRANCH"
                    value={formik.values.workDistance}
                    onChange={formik.handleChange}
                  />
                </Grid>
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.workIsCommunication}
                        onChange={formik.handleChange}
                        name="workIsCommunication"
                      />
                    }
                    label="Is This Communication Address"
                  />
                </Grid>
              </Grid>
            </CardContent>
          </Card>

          {/* Bank Details Section */}
          <Card sx={{ mb: 4 }}>
            <CardContent sx={{ p: 3 }}>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  mb: 3,
                }}
              >
                <Typography variant="h6" sx={{ color: '#1a237e', fontWeight: 600 }}>
                  Bank Details:
                </Typography>
                <Button
                  variant="contained"
                  sx={{
                    backgroundColor: '#ffc107',
                    color: '#000',
                    '&:hover': { backgroundColor: '#ffb300' },
                  }}
                >
                  Bank Add/Verify
                </Button>
              </Box>
              {bankDetails.map((bank, index) => (
                <Box
                  key={index}
                  sx={{ mb: 4, p: 3, border: '1px solid #e0e0e0', borderRadius: 2, backgroundColor: '#fafafa' }}
                >
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 2 }}>
                    <Typography variant="subtitle2">Bank Account {index + 1}</Typography>
                    {bankDetails.length > 1 && (
                      <IconButton
                        size="small"
                        onClick={() => removeBankDetail(index)}
                        color="error"
                      >
                        <DeleteIcon />
                      </IconButton>
                    )}
                  </Box>
                  <Grid container spacing={3}>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Beneficiary"
                        placeholder="BENEFICIARY"
                        value={bank.beneficiary}
                        onChange={(e) =>
                          updateBankDetail(index, 'beneficiary', e.target.value)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="A/C No"
                        placeholder="A/C NO"
                        value={bank.accountNo}
                        onChange={(e) =>
                          updateBankDetail(index, 'accountNo', e.target.value)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Bank Name"
                        placeholder="BANK NAME"
                        value={bank.bankName}
                        onChange={(e) =>
                          updateBankDetail(index, 'bankName', e.target.value)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="Bank Branch"
                        placeholder="BANK BRANCH"
                        value={bank.bankBranch}
                        onChange={(e) =>
                          updateBankDetail(index, 'bankBranch', e.target.value)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        select
                        label="A/C Type"
                        value={bank.accountType}
                        onChange={(e) =>
                          updateBankDetail(index, 'accountType', e.target.value)
                        }
                        SelectProps={{
                          displayEmpty: true,
                        }}
                      >
                        <MenuItem value="">
                          <em>Select A/C Type</em>
                        </MenuItem>
                        {accountTypeOptions.map((option) => (
                          <MenuItem key={option.value} value={option.value}>
                            {option.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <TextField
                        fullWidth
                        label="IFSC Code"
                        placeholder="IFSC CODE"
                        value={bank.ifscCode}
                        onChange={(e) =>
                          updateBankDetail(index, 'ifscCode', e.target.value)
                        }
                      />
                    </Grid>
                    <Grid item xs={12} md={4}>
                      <Box sx={{ display: 'flex', gap: 1 }}>
                        <TextField
                          fullWidth
                          label="MICR Code"
                          placeholder="MICR CODE"
                          value={bank.micrCode}
                          onChange={(e) =>
                            updateBankDetail(index, 'micrCode', e.target.value)
                          }
                        />
                        {index === bankDetails.length - 1 && (
                          <IconButton
                            onClick={addBankDetail}
                            sx={{
                              backgroundColor: '#1a237e',
                              color: 'white',
                              '&:hover': { backgroundColor: '#283593' },
                            }}
                          >
                            <AddIcon />
                          </IconButton>
                        )}
                      </Box>
                    </Grid>
                  </Grid>
                </Box>
              ))}
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2, mb: 3 }}>
            <Button
              variant="outlined"
              onClick={() => navigate('/customer-info')}
              sx={{
                borderColor: '#6a1b9a',
                color: '#6a1b9a',
                '&:hover': { borderColor: '#8e24aa', backgroundColor: '#f3e5f5' },
              }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              sx={{
                backgroundColor: '#6a1b9a',
                '&:hover': { backgroundColor: '#8e24aa' },
              }}
            >
              Save
            </Button>
          </Box>
        </form>
      </Paper>
    </DashboardLayout>
  )
}

export default AddCustomer
